import { 
  Dna, Cpu as ComputerIcon, Wrench, Zap as EnergyIcon, Rocket, Sword,
  Zap, Factory, Microscope, Building2, RadioTower, Warehouse, Anchor,
  Sprout, HardDrive, Database, Triangle, Shield, Crosshair, Wind, Square,
  Box, Gem, Wheat, Fish, Battery, Signal, Pickaxe, Activity, Satellite, Moon, Sun, CloudFog
} from 'lucide-react';
import { TechTree, Race, PlanetType, Building, ShipClass, FormationStats, FormationId, MarketState, ResourceType, DiplomacyState } from './types';

export const HEX_SIZE = 48; 
export const MOVE_SPEED = 25; 
export const COLONY_COST = 5000;
export const BASE_GROWTH_RATE = 0.05;

// --- MARKET CONSTANTS ---
export const INITIAL_MARKET: MarketState = {
  alloys: { price: 15, trend: 'stable', volatility: 2 },
  dilithium: { price: 25, trend: 'stable', volatility: 4 },
  biomatter: { price: 5, trend: 'stable', volatility: 1 }
};

export const RESOURCE_CONFIG: Record<ResourceType, { name: string, icon: any, color: string }> = {
  alloys: { name: 'Duranium Alloys', icon: Box, color: 'text-orange-400' },
  dilithium: { name: 'Dilithium Crystal', icon: Gem, color: 'text-purple-400' },
  biomatter: { name: 'Biomatter', icon: Wheat, color: 'text-emerald-400' }
};

export const INITIAL_DIPLOMACY: DiplomacyState = {
    1: { status: 'peace', opinion: 50 }, // Klingons
    2: { status: 'peace', opinion: 50 }, // Romulans
    3: { status: 'peace', opinion: 40 }, // Cardassians
    4: { status: 'peace', opinion: 60 }, // Ferengi
    5: { status: 'peace', opinion: 20 }, // Dominion
    6: { status: 'war', opinion: 0 },    // Borg (Always hostile initially)
    7: { status: 'peace', opinion: 30 }  // Breen
};

export const TECH_TREE: TechTree = {
  Biotech: {
    icon: Dna,
    color: "text-emerald-400",
    levels: ["Hydroponics", "Bionics", "Genetics", "Metagenics", "Climate Control", "Air Conversion", "Biofiltration", "Eco-modification", "Xenobiology", "Silicobiology"]
  },
  Computers: {
    icon: ComputerIcon,
    color: "text-blue-400",
    levels: ["Microtape Storage", "Linguistics", "Data Imaging", "Duotronics", "Crystal Memory", "Quadritronics", "Isolinear Optics", "Circuit Distortion", "Ultraconduction", "Positronics"]
  },
  Construction: {
    icon: Wrench,
    color: "text-orange-400",
    levels: ["Gamma Welding", "Integrity Fields", "Epitaxy", "Phase Transition", "Warp Fields", "Diffusion Bonding", "Nuclear Epitaxy", "Electron Bonding", "Quantum Epitaxy", "Holographics"]
  },
  Energy: {
    icon: EnergyIcon,
    color: "text-yellow-400",
    levels: ["Force Fields", "Subspace Physics", "Graviton Physics", "Power Distribution", "Antimatter Fusion", "Virtual Particles", "Ultraconductors", "Wave Analysis", "Determinacy"]
  },
  Propulsion: {
    icon: Rocket,
    color: "text-purple-400",
    levels: ["Warp Drive", "Distortion", "Plasma Injection", "Microdistortion", "Field Geometry", "Superconduction", "Field Compression", "Charge reversal", "Ultraconductivity"]
  },
  Weapons: {
    icon: Sword,
    color: "text-red-400",
    levels: ["Beam Emitters", "Torpedo Hardening", "Beam Hardening", "Matter Packets", "Multifrequency Beams", "Subspace Guidance", "Micropulsing", "Compression", "Quantum Shielding", "Ultra Emitters"]
  }
};

export const FORMATIONS: Record<FormationId, FormationStats> = {
    standard: {
        id: 'standard',
        name: 'Standard Cruise',
        desc: 'Balanced systems with no significant strengths or weaknesses.',
        icon: Square,
        modifiers: { damage: 1.0, accuracy: 1.0, evasion: 1.0, defense: 1.0 }
    },
    wedge: {
        id: 'wedge',
        name: 'Alpha Wedge',
        desc: 'Focus fire on a single point. Increases damage but exposes flanks.',
        icon: Triangle,
        modifiers: { damage: 1.25, accuracy: 1.1, evasion: 0.8, defense: 0.9 }
    },
    wall: {
        id: 'wall',
        name: 'Phalanx Wall',
        desc: 'Overlap shields to maximize defense at cost of mobility.',
        icon: Shield,
        modifiers: { damage: 0.9, accuracy: 1.0, evasion: 0.6, defense: 1.3 }
    },
    skirmish: {
        id: 'skirmish',
        name: 'Loose Skirmish',
        desc: 'High speed maneuvers to evade fire. Reduces weapon coherence.',
        icon: Wind,
        modifiers: { damage: 0.8, accuracy: 0.9, evasion: 1.3, defense: 1.0 }
    },
    echelon: {
        id: 'echelon',
        name: 'Echelon Lock',
        desc: 'Optimized targeting sensors for long range accuracy.',
        icon: Crosshair,
        modifiers: { damage: 1.0, accuracy: 1.3, evasion: 0.9, defense: 0.9 }
    }
};

// Updated positions to use relative coordinates (0.0 - 1.0) instead of fixed hex IDs
export const MAJOR_RACES: Race[] = [
  { id: 0, name: "united federation of planets", homeworld: "Earth", color: "text-blue-400", relX: 0.5, relY: 0.85, bgColor: "bg-blue-500", borderColor: "border-blue-400", hexColor: "rgba(59, 130, 246, 0.15)" }, 
  { id: 1, name: "Klingon Empire", homeworld: "Qo'noS", color: "text-red-500", relX: 0.85, relY: 0.15, bgColor: "bg-red-600", borderColor: "border-red-500", hexColor: "rgba(220, 38, 38, 0.15)" },
  { id: 2, name: "Romulan Star Empire", homeworld: "Romulus", color: "text-emerald-500", relX: 0.85, relY: 0.85, bgColor: "bg-emerald-600", borderColor: "border-emerald-500", hexColor: "rgba(16, 185, 129, 0.15)" },
  { id: 3, name: "Cardassian Union", homeworld: "Cardassia Prime", color: "text-orange-400", relX: 0.15, relY: 0.75, bgColor: "bg-orange-500", borderColor: "border-orange-400", hexColor: "rgba(249, 115, 22, 0.15)" },
  { id: 4, name: "Ferengi Alliance", homeworld: "Ferenginar", color: "text-yellow-600", relX: 0.15, relY: 0.15, bgColor: "bg-yellow-700", borderColor: "border-yellow-600", hexColor: "rgba(202, 138, 4, 0.15)" },
  { id: 5, name: "Dominion", homeworld: "Founder's World", color: "text-purple-500", relX: 0.05, relY: 0.5, bgColor: "bg-purple-600", borderColor: "border-purple-500", hexColor: "rgba(147, 51, 234, 0.15)" },
  { id: 6, name: "Borg Collective", homeworld: "Unicomplex", color: "text-green-500", relX: 0.95, relY: 0.5, bgColor: "bg-green-700", borderColor: "border-green-500", hexColor: "rgba(34, 197, 94, 0.2)" },
  { id: 7, name: "Breen Confederacy", homeworld: "Breen", color: "text-cyan-200", relX: 0.5, relY: 0.1, bgColor: "bg-cyan-800", borderColor: "border-cyan-300", hexColor: "rgba(103, 232, 249, 0.2)" }
];

export const MINOR_RACES: Race[] = [
    { id: 100, name: "Bajorans", homeworld: "Bajor", trait: "Spiritual", color: "text-orange-300", relX: 0, relY: 0, bgColor: "bg-orange-400", borderColor: "border-orange-200", hexColor: "rgba(253, 186, 116, 0.2)", isMinor: true },
    { id: 101, name: "Vulcans", homeworld: "Vulcan", trait: "Logical", color: "text-red-300", relX: 0, relY: 0, bgColor: "bg-red-400", borderColor: "border-red-200", hexColor: "rgba(252, 165, 165, 0.2)", isMinor: true },
    { id: 102, name: "Andorians", homeworld: "Andoria", trait: "Militaristic", color: "text-blue-300", relX: 0, relY: 0, bgColor: "bg-blue-400", borderColor: "border-blue-200", hexColor: "rgba(147, 197, 253, 0.2)", isMinor: true },
    { id: 103, name: "Gorn Hegemony", homeworld: "Gornar", trait: "Hostile", color: "text-green-600", relX: 0, relY: 0, bgColor: "bg-green-800", borderColor: "border-green-600", hexColor: "rgba(22, 163, 74, 0.3)", isMinor: true },
    { id: 104, name: "Tholian Assembly", homeworld: "Tholia", trait: "Xenophobic", color: "text-red-600", relX: 0, relY: 0, bgColor: "bg-red-800", borderColor: "border-red-600", hexColor: "rgba(220, 38, 38, 0.3)", isMinor: true },
    { id: 105, name: "Talarians", homeworld: "Talar", trait: "Warrior", color: "text-yellow-200", relX: 0, relY: 0, bgColor: "bg-yellow-300", borderColor: "border-yellow-100", hexColor: "rgba(253, 224, 71, 0.2)", isMinor: true },
    { id: 106, name: "Tamarians", homeworld: "Darmok", trait: "Enigmatic", color: "text-emerald-300", relX: 0, relY: 0, bgColor: "bg-emerald-400", borderColor: "border-emerald-200", hexColor: "rgba(110, 231, 183, 0.2)", isMinor: true },
    { id: 107, name: "Trill", homeworld: "Trill", trait: "Symbiotic", color: "text-purple-300", relX: 0, relY: 0, bgColor: "bg-purple-400", borderColor: "border-purple-200", hexColor: "rgba(216, 180, 254, 0.2)", isMinor: true },
    { id: 108, name: "Sheliak Corporate", homeworld: "Shelia", trait: "Legalistic", color: "text-slate-200", relX: 0, relY: 0, bgColor: "bg-slate-400", borderColor: "border-slate-200", hexColor: "rgba(148, 163, 184, 0.2)", isMinor: true },
    { id: 109, name: "Malcorians", homeworld: "Malcor III", trait: "Isolationist", color: "text-pink-300", relX: 0, relY: 0, bgColor: "bg-pink-400", borderColor: "border-pink-200", hexColor: "rgba(249, 168, 212, 0.2)", isMinor: true }
];

export const PLANET_TYPES: PlanetType[] = [
  { type: 'M-Class', color: 'bg-emerald-500', shadow: 'shadow-emerald-500/50', desc: 'Habitable, Terran-like', habitable: true, growthMod: 1.0, miningBonus: 'biomatter' }, 
  { type: 'K-Class', color: 'bg-orange-400', shadow: 'shadow-orange-500/50', desc: 'Arid, Mars-like', habitable: true, growthMod: 0.7, miningBonus: 'alloys' },     
  { type: 'L-Class', color: 'bg-yellow-200', shadow: 'shadow-yellow-500/50', desc: 'Marginal life, lush vegetation', habitable: true, growthMod: 0.8, miningBonus: 'biomatter' }, 
  { type: 'Y-Class', color: 'bg-yellow-600', shadow: 'shadow-yellow-700/50', desc: 'Demon class, toxic atmosphere', habitable: false, growthMod: 0.1, miningBonus: 'dilithium' }, 
  { type: 'Gas Giant', color: 'bg-purple-400', shadow: 'shadow-purple-500/50', desc: 'Orbital Platform Capable', habitable: true, growthMod: 0, miningBonus: 'dilithium' }, 
  { type: 'Ice World', color: 'bg-cyan-200', shadow: 'shadow-cyan-500/50', desc: 'Frozen, low habitability', habitable: true, growthMod: 0.4, miningBonus: 'alloys' },
  { type: 'Asteroid', color: 'bg-stone-500', shadow: 'shadow-stone-500/50', desc: 'Mineral rich rock', habitable: true, growthMod: 0, miningBonus: 'alloys' },
  { type: 'Neutron Star', color: 'bg-cyan-100', shadow: 'shadow-cyan-500/100', desc: 'Ultra-dense remnant', habitable: false, growthMod: 0, miningBonus: 'dilithium' },
  { type: 'Plasma Storm', color: 'bg-orange-600', shadow: 'shadow-orange-500/80', desc: 'High energy plasma', habitable: false, growthMod: 0, miningBonus: 'dilithium' },
  { type: 'Anomaly', color: 'bg-fuchsia-500', shadow: 'shadow-fuchsia-500/50', desc: 'Spacetime distortion', habitable: false, growthMod: 0, miningBonus: 'biomatter' },
  { type: 'Dark Matter', color: 'bg-violet-900', shadow: 'shadow-violet-500/50', desc: 'Exotic matter node', habitable: false, growthMod: 0, miningBonus: 'dilithium' },
  { type: 'Wormhole', color: 'bg-indigo-300', shadow: 'shadow-indigo-500/100', desc: 'Subspace aperture', habitable: false, growthMod: 0, miningBonus: null },
  { type: 'Protostar', color: 'bg-amber-500', shadow: 'shadow-red-500/80', desc: 'Nascent star', habitable: false, growthMod: 0, miningBonus: 'alloys' },
  { type: 'Magnetar', color: 'bg-pink-300', shadow: 'shadow-pink-500/100', desc: 'Magnetic monster', habitable: false, growthMod: 0, miningBonus: 'dilithium' },
  // New Planets
  { type: 'Super Saturn', color: 'bg-amber-200', shadow: 'shadow-amber-500/50', desc: 'Massive ring system', habitable: true, growthMod: 0, miningBonus: 'dilithium' }, // 14
  { type: 'Super M-Class', color: 'bg-emerald-600', shadow: 'shadow-emerald-400/50', desc: 'Super-habitable Giant', habitable: true, growthMod: 1.5, miningBonus: 'biomatter' }, // 15
  { type: 'Fire World', color: 'bg-red-600', shadow: 'shadow-red-600/80', desc: 'Volcanic surface', habitable: false, growthMod: 0, miningBonus: 'alloys' }, // 16
  { type: 'Dark World', color: 'bg-slate-950', shadow: 'shadow-black/100', desc: 'Light-absorbing surface', habitable: false, growthMod: 0, miningBonus: 'dilithium' }, // 17
  { type: 'Scorched World', color: 'bg-orange-600', shadow: 'shadow-orange-600/80', desc: 'Extreme surface temperatures', habitable: false, growthMod: 0, miningBonus: 'alloys' }, // 18
  { type: 'Ocean World', color: 'bg-blue-500', shadow: 'shadow-blue-500/60', desc: 'Global ocean', habitable: true, growthMod: 1.1, miningBonus: 'biomatter' }, // 19
  { type: 'Mega Jupiter', color: 'bg-orange-300', shadow: 'shadow-orange-400/60', desc: 'Brown Dwarf Candidate', habitable: true, growthMod: 0, miningBonus: 'dilithium' }, // 20
];

export const SOL_PLANETS = [
  { name: "Mercury", type: 1, slots: 4, moons: 0 },
  { name: "Venus", type: 3, slots: 8, moons: 0 },
  { name: "Earth", type: 0, slots: 18, moons: 1 },
  { name: "Mars", type: 1, slots: 10, moons: 2 },
  { name: "Jupiter", type: 4, slots: 15, moons: 79 },
  { name: "Saturn", type: 4, slots: 14, moons: 82 },
  { name: "Uranus", type: 5, slots: 8, moons: 27 },
  { name: "Neptune", type: 5, slots: 8, moons: 14 },
  { name: "Pluto", type: 5, slots: 3, moons: 5 }
];

export const SYSTEM_NAMES = ["Wolf 359", "Cestus III", "Rigel Prime", "Deneb IV", "Antares", "Canopus", "Sirius", "Vega", "Arcturus", "Capella", "Pollux", "Castor", "Procyon", "Spica", "Regulus", "Risa", "Praxis", "Remus", "Chaltok", "Vela", "Zeta Reticuli", "Barnard's Star", "Tau Ceti", "Alpha Centauri", "Talos IV", "Genesis", "Excalbia", "Organia", "Chin'toka", "Omekla", "Vandrok", "Lazon", "Ocampa", "Talax", "Sikaris", "Vidiia", "Rakosa", "Nezu", "Krenim", "Malon", "Devore", "Turei", "Vaadwaur", "Xindus", "Azati Prime", "Coridan", "Archer IV", "Terra Nova", "Sherman's Planet", "Nimbus III", "Galorndon Core", "Setlik III", "Minos Korva", "Nelvana III", "Draylon II", "Gault", "Khitomer", "Narendra III", "Rura Penthe", "Ty'Gokor", "Bolarus IX", "Benzar", "Cait", "Edo", "Angel One", "Rubicun III", "Mintaka III", "Malcor III", "Kaelon II", "T'Lani III", "Yridia", "Zibalia", "Meridian", "Gaia", "Banea", "Rakhar", "Sikaris", "Draven", "Alastria", "Midos V", "Qualor II"];

// Helper to generate UFP buildings
const FED_ID = 0;
const FED_BUILDINGS: Building[] = [
  // FARMS (Biotech)
  { id: 'fed_farm_prim', name: 'Primitive Farm', cost: 100, resourceCost: { biomatter: 50 }, Icon: Sprout, popBonus: 0.05, raceReq: FED_ID },
  { id: 'fed_farm_1', name: 'Farming Centre I', cost: 200, resourceCost: { biomatter: 100 }, Icon: Sprout, popBonus: 0.08, raceReq: FED_ID, techReq: { category: 'Biotech', level: 0 } },
  { id: 'fed_farm_2', name: 'Automated Farm II', cost: 350, resourceCost: { biomatter: 150, alloys: 20 }, Icon: Sprout, popBonus: 0.10, raceReq: FED_ID, techReq: { category: 'Biotech', level: 0 } },
  { id: 'fed_farm_3', name: 'Automated Farm III', cost: 500, resourceCost: { biomatter: 200, alloys: 40 }, Icon: Sprout, popBonus: 0.12, raceReq: FED_ID, techReq: { category: 'Biotech', level: 1 } },
  { id: 'fed_farm_11', name: 'Automated Farm XI', cost: 3000, resourceCost: { biomatter: 500, alloys: 200 }, Icon: Sprout, popBonus: 0.28, raceReq: FED_ID, techReq: { category: 'Biotech', level: 9 } },

  // REPLICATION PLANTS (Construction)
  { id: 'fed_repl_1', name: 'Replication Plant I', cost: 400, resourceCost: { alloys: 100, dilithium: 20 }, Icon: Factory, credits: 80, raceReq: FED_ID, techReq: { category: 'Construction', level: 0 } },
  { id: 'fed_repl_11', name: 'Replication Plant XI', cost: 4200, resourceCost: { alloys: 800, dilithium: 200 }, Icon: Factory, credits: 550, raceReq: FED_ID, techReq: { category: 'Construction', level: 9 } },

  // PLASMA REACTORS (Energy)
  { id: 'fed_reac_1', name: 'Plasma Reactor I', cost: 500, resourceCost: { alloys: 150, dilithium: 50 }, Icon: Zap, credits: 120, raceReq: FED_ID, techReq: { category: 'Energy', level: 0 } },
  { id: 'fed_reac_11', name: 'Plasma Reactor XI', cost: 4000, resourceCost: { alloys: 1000, dilithium: 500 }, Icon: Zap, credits: 700, raceReq: FED_ID, techReq: { category: 'Energy', level: 9 } },

  // UNIVERSITIES
  { id: 'fed_uni_1', name: 'University I', cost: 800, resourceCost: { alloys: 200, dilithium: 20 }, Icon: Microscope, rp: 30, raceReq: FED_ID, techReq: { category: 'Computers', level: 0 } },
  { id: 'fed_uni_11', name: 'University XI', cost: 5300, resourceCost: { alloys: 1000, dilithium: 300 }, Icon: Microscope, rp: 260, raceReq: FED_ID, techReq: { category: 'Computers', level: 9 } },

  // DATABANKS
  { id: 'fed_data_1', name: 'Databank I', cost: 800, resourceCost: { alloys: 200 }, Icon: Database, rp: 10, influenceBonus: 1, raceReq: FED_ID, techReq: { category: 'Weapons', level: 0 } },
  { id: 'fed_data_11', name: 'Databank XI', cost: 5300, resourceCost: { alloys: 1200 }, Icon: Database, rp: 120, influenceBonus: 6, raceReq: FED_ID, techReq: { category: 'Weapons', level: 9 } },
];

export const BUILDINGS: { Infrastructure: Building[], Orbital: Building[] } = {
  Infrastructure: [
    ...FED_BUILDINGS,
    // Generic buildings for other races
    { id: 'power', name: 'Fusion Reactor', cost: 400, resourceCost: { alloys: 100 }, Icon: Zap, rp: 0, credits: 100, popBonus: 0 },
    { id: 'factory', name: 'Industrial Hub', cost: 800, resourceCost: { alloys: 300 }, Icon: Factory, rp: 0, credits: 250, popBonus: 0 },
    { id: 'lab', name: 'Science Academy', cost: 1200, resourceCost: { alloys: 200, dilithium: 100 }, Icon: Microscope, rp: 50, credits: 0, popBonus: 0 },
    { id: 'housing', name: 'Habitat Complex', cost: 1000, resourceCost: { alloys: 400, biomatter: 200 }, Icon: Building2, rp: 0, credits: 0, popBonus: 0.05 },

    // --- NEW GENERIC BUILDINGS ---
    { id: 'AQUACULTURE_CENTRE', name: 'Aquaculture Centre', cost: 300, resourceCost: { biomatter: 100 }, Icon: Fish, popBonus: 0.1, restrictions: ['OnePerSystem', 'OceanicPlanet'], techReq: { category: 'Biotech', level: 1 } },
    { id: 'AQUATIC_DEUTERIUM_PLANT', name: 'Aquatic Deuterium Plant', cost: 400, resourceCost: { alloys: 100, dilithium: 50 }, Icon: Battery, credits: 150, restrictions: ['OnePerSystem', 'OceanicPlanet'], techReq: { category: 'Energy', level: 2 } },
    { id: 'BUNKER_NETWORK', name: 'Bunker Network', cost: 500, resourceCost: { alloys: 300 }, Icon: Shield, influenceBonus: 2, techReq: { category: 'Construction', level: 1 } },
    { id: 'CHARGE_COLLECTORS', name: 'Charge Collectors', cost: 200, resourceCost: { alloys: 50 }, Icon: Zap, credits: 50, techReq: { category: 'Energy', level: 1 } },
    { id: 'COMMUNICATIONS_GRID', name: 'Communications Grid', cost: 600, resourceCost: { alloys: 100, dilithium: 20 }, Icon: Signal, influenceBonus: 3, techReq: { category: 'Computers', level: 2 } },
    { id: 'DEUTERIUM_COLLECTOR', name: 'Deuterium Collector', cost: 1000, resourceCost: { alloys: 400, dilithium: 100 }, Icon: CloudFog, credits: 300, restrictions: ['GasGiant'], techReq: { category: 'Propulsion', level: 2 } },
    { id: 'DEUTERIUM_EXTRACTOR', name: 'Deuterium Extractor', cost: 1500, resourceCost: { alloys: 600, dilithium: 200 }, Icon: CloudFog, credits: 500, restrictions: ['Nebula'], techReq: { category: 'Propulsion', level: 4 } },
    { id: 'DILITHIUM_REFINERY', name: 'Dilithium Refinery', cost: 800, resourceCost: { alloys: 300 }, Icon: Gem, credits: 0, restrictions: ['OnePerSystem'], techReq: { category: 'Energy', level: 3 } },
    { id: 'DURANIUM_MINE', name: 'Duranium Mine', cost: 800, resourceCost: { alloys: 100 }, Icon: Pickaxe, credits: 200, restrictions: ['OnePerSystem'], techReq: { category: 'Construction', level: 2 } },
    { id: 'ASTEROID_MINING_RIG', name: 'Asteroid Mining Rig', cost: 300, resourceCost: { alloys: 50 }, Icon: Pickaxe, credits: 150, restrictions: ['AsteroidBody'], techReq: { category: 'Construction', level: 1 } },
    { id: 'HEALTH_CENTRE', name: 'Health Centre', cost: 400, resourceCost: { biomatter: 150 }, Icon: Activity, popBonus: 0.15, techReq: { category: 'Biotech', level: 2 } },
    { id: 'IMMUNOLOGY_CENTRE', name: 'Immunology Centre', cost: 900, resourceCost: { biomatter: 400 }, Icon: Activity, popBonus: 0.25, techReq: { category: 'Biotech', level: 5 }, prerequisite: 'HEALTH_CENTRE' },
    { id: 'ISOLINEAR_SCANNER', name: 'Isolinear Scanner', cost: 1200, resourceCost: { alloys: 200, dilithium: 100 }, Icon: RadioTower, influenceBonus: 5, techReq: { category: 'Computers', level: 4 } },
    { id: 'MINING_SPACEPORT', name: 'Mining Spaceport', cost: 2000, resourceCost: { alloys: 800 }, Icon: Anchor, credits: 600, restrictions: ['OnePerSystem', 'Asteroids'], techReq: { category: 'Construction', level: 3 } },
    { id: 'MOON_HABITATION', name: 'Moon Habitation', cost: 1500, resourceCost: { alloys: 500, biomatter: 200 }, Icon: Moon, popBonus: 0.2, restrictions: ['OnePerSystem', 'Moons'], techReq: { category: 'Construction', level: 4 } },
    { id: 'SHIELD_GENERATOR', name: 'Shield Generator', cost: 2000, resourceCost: { alloys: 600, dilithium: 300 }, Icon: Shield, influenceBonus: 4, techReq: { category: 'Energy', level: 4 } },
    { id: 'SOLAR_ARRAY', name: 'Solar Array', cost: 150, resourceCost: { alloys: 40 }, Icon: Sun, credits: 40, techReq: { category: 'Energy', level: 0 } },
    { id: 'WIND_TURBINES', name: 'Wind Turbines', cost: 100, resourceCost: { alloys: 20 }, Icon: Wind, credits: 30, techReq: { category: 'Energy', level: 0 } },
    { id: 'SURPLUS_DEPOT', name: 'Surplus Depot', cost: 500, resourceCost: { alloys: 200 }, Icon: Warehouse, credits: 100, techReq: { category: 'Construction', level: 1 } },
    { id: 'TACHYON_DETECTION_GRID', name: 'Tachyon Detection Grid', cost: 3000, resourceCost: { alloys: 1000, dilithium: 500 }, Icon: Satellite, influenceBonus: 8, techReq: { category: 'Computers', level: 6 } },
    { id: 'THERMAL_TETHERS', name: 'Thermal Tethers', cost: 300, resourceCost: { alloys: 100 }, Icon: Zap, credits: 80, techReq: { category: 'Energy', level: 1 } },
  ],
  Orbital: [
    { id: 'outpost', name: 'Subspace Array', cost: 1500, resourceCost: { alloys: 500, dilithium: 200 }, Icon: RadioTower, influenceBonus: 1 },
    { id: 'starbase', name: 'Starbase v1', cost: 5000, resourceCost: { alloys: 2000, dilithium: 500 }, Icon: Warehouse, influenceBonus: 2 },
    { id: 'shipyard', name: 'Orbital Shipyard', cost: 3000, resourceCost: { alloys: 1500 }, Icon: Anchor, influenceBonus: 1 },
  ]
};

export const SHIP_CLASSES: ShipClass[] = [
  { id: 'scout', name: 'Oberth Class Scout', cost: 500, resourceCost: { alloys: 100, dilithium: 50 }, hull: 100, shields: 50, damage: 20, accuracy: 0.9, evasion: 0.7, techReq: null },
  { id: 'colony_ship', name: 'Colony Ship', cost: 8000, resourceCost: { alloys: 1000, biomatter: 1000, dilithium: 500 }, hull: 200, shields: 100, damage: 0, accuracy: 0, evasion: 0.4, techReq: null, abilities: ['colonize'] },
  { id: 'const_ship', name: 'Construction Ship', cost: 5000, resourceCost: { alloys: 2000, dilithium: 500 }, hull: 400, shields: 200, damage: 0, accuracy: 0, evasion: 0.2, techReq: null, abilities: ['construct'] },
  { id: 'destroyer', name: 'Miranda Class Destroyer', cost: 1200, resourceCost: { alloys: 300, dilithium: 100 }, hull: 300, shields: 150, damage: 50, accuracy: 0.8, evasion: 0.5, techReq: { category: 'Weapons', level: 1 } },
  { id: 'cruiser', name: 'Excelsior Class Cruiser', cost: 3000, resourceCost: { alloys: 800, dilithium: 300 }, hull: 800, shields: 400, damage: 120, accuracy: 0.7, evasion: 0.3, techReq: { category: 'Energy', level: 2 } },
  { id: 'battleship', name: 'Galaxy Class Battleship', cost: 6000, resourceCost: { alloys: 1500, dilithium: 600 }, hull: 1500, shields: 800, damage: 250, accuracy: 0.85, evasion: 0.2, techReq: { category: 'Construction', level: 3 } },
  { id: 'dreadnought', name: 'Sovereign Class Dreadnought', cost: 12000, resourceCost: { alloys: 3000, dilithium: 1500 }, hull: 3000, shields: 1500, damage: 600, accuracy: 0.9, evasion: 0.1, techReq: { category: 'Weapons', level: 5 } },
];
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Aperture, Microscope, HardDrive, Orbit, X, MapPin, Flag, Map as MapIcon, Hexagon,
  Anchor, Rocket, Shield, Crosshair, Skull, Activity, Target, Eye, Settings, Save, RotateCcw,
  TrendingUp, TrendingDown, Minus, Cloud, Zap, Handshake, Users, Hammer, RadioTower, 
  Play, Globe, EyeOff, Fish, Battery, Signal, Pickaxe, Satellite, Moon, Sun, CloudFog, Warehouse,
  Trash2, LogOut, Navigation, Gift, FileSignature, AlertTriangle, HeartHandshake, Swords, MessageCircleX,
  ScanEye, Info
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

import { 
  HEX_SIZE, MOVE_SPEED, COLONY_COST, BASE_GROWTH_RATE,
  TECH_TREE, MAJOR_RACES, MINOR_RACES, PLANET_TYPES, SOL_PLANETS, SYSTEM_NAMES, BUILDINGS, SHIP_CLASSES, FORMATIONS,
  INITIAL_MARKET, RESOURCE_CONFIG, INITIAL_DIPLOMACY
} from './constants';

import { 
  GalaxyDataMap, ColonyMap, TechLevelsState, SaveState, CameraState, TechLevel, StarSystem,
  Fleet, Ship, ShipClass, CombatState, CombatLogEntry, ColonyDetails, FormationId,
  MarketState, InventoryState, WeatherPhenomenon, ResourceType, DiplomacyState, Structure, GameSettings, RelationStatus,
  Building, FormationStats, DiplomaticRelation, Race
} from './types';

// Utility functions
const pseudoRandom = (seed: number) => {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
};

const getHexDistance = (q1: number, r1: number, q2: number, r2: number) => {
  return (Math.abs(q1 - q2) + Math.abs(q1 + r1 - q2 - r2) + Math.abs(r1 - r2)) / 2;
};

const HEX_DIRECTIONS = [
  [1, 0], [1, -1], [0, -1],
  [-1, 0], [-1, 1], [0, 1]
];

const FALLBACK_IMAGES: Record<string, string> = {
  'BLACK_HOLE': 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=800&auto=format&fit=crop',
  'WORMHOLE': 'https://images.unsplash.com/photo-1506443432602-ac2fcd6f54e0?q=80&w=800&auto=format&fit=crop',
  'NEBULA': 'https://images.unsplash.com/photo-1543722530-d2c3201371e7?q=80&w=800&auto=format&fit=crop',
  'STAR': 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?q=80&w=800&auto=format&fit=crop',
  'BINARY': 'https://images.unsplash.com/photo-1614730341194-75c60740a070?q=80&w=800&auto=format&fit=crop',
  'PULSAR': 'https://images.unsplash.com/photo-1614726365723-49cfae92782f?q=80&w=800&auto=format&fit=crop',
  'ASTEROID_FIELD': 'https://images.unsplash.com/photo-1614730341194-75c60740a070?q=80&w=800&auto=format&fit=crop',
  'ION_STORM': 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?q=80&w=800&auto=format&fit=crop',
  'OCEANIC': 'https://images.unsplash.com/photo-1506318137071-a8bcbfd0cc60?q=80&w=800&auto=format&fit=crop',
  'VOLCANIC': 'https://images.unsplash.com/photo-1467664631004-58beab1efe2d?q=80&w=800&auto=format&fit=crop',
  'ANCIENT': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=800&auto=format&fit=crop',
  'SHADOW': 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
  'DEFAULT': 'https://images.unsplash.com/photo-1542395687-340156557613?q=80&w=800&auto=format&fit=crop'
};

const renderSystemIcon = (type: StarSystem['type'], bg: string | undefined) => {
  switch (type) {
      case 'BLACK_HOLE':
          return (
            <div className="relative flex items-center justify-center w-12 h-12 pointer-events-none">
               <div className="absolute inset-0 bg-[conic-gradient(from_0deg,transparent,rgba(147,51,234,0.6),transparent)] rounded-full animate-spin-slow blur-[2px]"></div>
               <div className="absolute inset-2 bg-[conic-gradient(from_180deg,transparent,rgba(255,255,255,0.4),transparent)] rounded-full animate-spin-reverse blur-[1px]"></div>
               <div className="w-3.5 h-3.5 bg-black rounded-full border border-purple-500/50 shadow-[0_0_15px_rgba(147,51,234,0.9)] z-10 relative"></div>
            </div>
          );
      case 'BINARY':
          return (
              <div className="relative w-8 h-8 animate-spin-slower z-10 pointer-events-none">
                  <div className={`absolute top-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full ${bg || 'bg-orange-400'} shadow-[0_0_15px_rgba(251,146,60,0.8)]`}></div>
                  <div className={`absolute bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.8)]`}></div>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-white/10 rounded-full blur-[1px]"></div>
              </div>
          );
      case 'ASTEROID_FIELD':
          return (
             <div className="relative w-full h-full flex items-center justify-center pointer-events-none">
                <div className="absolute w-1 h-1 bg-stone-400 rounded-full top-1/3 left-1/3 shadow-sm animate-pulse"></div>
                <div className="absolute w-1.5 h-1.5 bg-stone-500 rounded-full top-1/2 left-2/3 shadow-sm"></div>
                <div className="absolute w-1 h-1 bg-stone-300 rounded-full bottom-1/3 left-1/2 shadow-sm"></div>
                <div className="w-2 h-2 bg-stone-400 rounded-full z-10 shadow-[0_0_10px_rgba(168,162,158,0.5)]"></div>
             </div>
          );
      case 'OCEANIC':
          return (
             <div className="relative pointer-events-none">
                <div className={`w-4 h-4 rounded-full shadow-[0_0_25px_rgba(59,130,246,0.6)] bg-blue-400 z-10`}></div>
                <div className={`absolute -inset-1 rounded-full bg-blue-500 opacity-30 blur-sm animate-pulse`}></div>
             </div>
          );
      case 'VOLCANIC':
          return (
             <div className="relative pointer-events-none">
                <div className={`w-4 h-4 rounded-full shadow-[0_0_25px_rgba(220,38,38,0.6)] bg-red-600 z-10`}></div>
                <div className={`absolute -inset-1 rounded-full bg-orange-600 opacity-40 blur-sm`}></div>
             </div>
          );
      case 'ANCIENT':
          return (
             <div className="relative pointer-events-none">
                <div className={`w-5 h-5 rounded-full shadow-[0_0_30px_rgba(234,179,8,0.5)] bg-yellow-200 z-10`}></div>
                <div className={`absolute -inset-2 rounded-full bg-yellow-500/20 blur-md`}></div>
             </div>
          );
      case 'SHADOW':
          return (
             <div className="relative pointer-events-none">
                <div className={`w-3.5 h-3.5 rounded-full shadow-[0_0_20px_rgba(147,51,234,0.4)] bg-slate-800 border border-purple-900 z-10`}></div>
                <div className={`absolute -inset-1 rounded-full bg-black opacity-60 blur-sm`}></div>
             </div>
          );
      case 'NEBULA':
      case 'PULSAR':
      case 'WORMHOLE':
      case 'ION_STORM':
      case 'HYPERGIANT':
      case 'NEUTRON_STAR':
      case 'WHITE_HOLE':
      case 'GRAVITON_ELLIPSE':
      case 'ROGUE_PLANET':
      case 'BADLANDS':
      case 'DARK_MATTER':
      case 'STAR':
      default:
          return (
             <div className="relative pointer-events-none">
                <div className={`w-3.5 h-3.5 rounded-full shadow-[0_0_20px_rgba(255,255,255,0.3)] ${bg || 'bg-yellow-400'} z-10`}></div>
                <div className={`absolute -inset-1 rounded-full ${bg || 'bg-yellow-400'} opacity-20 blur-sm`}></div>
             </div>
          );
  }
};

const decideAIFormation = (aiFleet: Fleet, enemyFleet: Fleet): FormationId => {
    const myShips = aiFleet.ships.map(s => SHIP_CLASSES.find(c => c.id === s.classId)!);
    const totalHull = myShips.reduce((acc, s) => acc + s.hull, 0);
    const currentHull = aiFleet.ships.reduce((acc, s) => acc + s.currentHull, 0);
    const hullPct = currentHull / totalHull;
    const enemyShips = enemyFleet.ships.map(s => SHIP_CLASSES.find(c => c.id === s.classId)!);
    const avgEvasion = enemyShips.reduce((acc, s) => acc + s.evasion, 0) / (enemyShips.length || 1);
    const totalEnemyDamage = enemyShips.reduce((acc, s) => acc + s.damage, 0);

    if (hullPct < 0.3) return 'skirmish';
    if (avgEvasion > 0.4) return 'echelon';
    if (totalEnemyDamage > currentHull * 0.4) return 'wall';
    if (currentHull > enemyFleet.ships.reduce((acc,s) => acc + s.currentHull, 0) * 1.5) return 'wedge';
    return 'standard';
};

const getOwnerColor = (owner: Race | null | undefined) => {
    if (!owner) return '#555';
    if (owner.hexColor && owner.hexColor.includes('rgba')) {
        return owner.hexColor.replace(/[\d.]+\)$/, '1)');
    }
    return owner.color.split('-')[1] || '#555';
};

const SystemView = ({ system }: { system: StarSystem }) => {
  return (
    <div className="w-full h-full relative overflow-hidden bg-black flex items-center justify-center">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900/50 via-black to-black"></div>
      <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
      
      {/* Central Body */}
      <div className="relative z-10 flex flex-col items-center animate-pulse-slow">
        {system.type === 'BLACK_HOLE' ? (
          <div className="w-32 h-32 rounded-full bg-black shadow-[0_0_100px_rgba(147,51,234,0.8)] border-2 border-purple-500/50"></div>
        ) : system.type === 'NEUTRON_STAR' ? (
          <div className="w-16 h-16 rounded-full bg-cyan-100 shadow-[0_0_80px_rgba(34,211,238,1)] animate-pulse"></div>
        ) : (
          <div className={`w-24 h-24 rounded-full ${system.raceBg?.split(' ')[0] || 'bg-yellow-400'} shadow-[0_0_80px_rgba(250,204,21,0.6)]`}></div>
        )}
      </div>

      {/* Orbiting Planets Visualization */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {system.planets.map((planet, i) => (
          <div 
            key={i}
            className="absolute border border-white/5 rounded-full"
            style={{
              width: `${(i + 1) * 120 + 100}px`,
              height: `${(i + 1) * 120 + 100}px`,
              animation: `spin ${Math.max(20, (i + 1) * 15)}s linear infinite`
            }}
          >
            <div 
              className={`absolute top-1/2 -right-3 w-6 h-6 rounded-full ${planet.color} shadow-[0_0_15px_currentColor] border border-white/20`} 
              style={{ marginTop: '-12px' }}
            >
              {planet.moons > 0 && (
                <div className="absolute -top-3 -right-3 w-2 h-2 bg-slate-400 rounded-full animate-ping opacity-50"></div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="absolute bottom-6 left-0 right-0 text-center z-20">
        <h3 className="text-3xl font-black uppercase tracking-widest text-white drop-shadow-lg">{system.name}</h3>
        <p className="text-blue-400 text-sm font-bold uppercase tracking-[0.4em] mt-2">{system.type.replace('_', ' ')}</p>
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .animate-spin-slow { animation: spin 20s linear infinite; }
      `}</style>
    </div>
  );
};

export default function App() {
  // --- Game State ---
  const [gameState, setGameState] = useState<'MENU' | 'PLAYING'>('MENU');
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<GameSettings>({
      mapWidth: 60,
      mapHeight: 40,
      fogOfWar: true,
      difficulty: 'normal'
  });

  // State Management
  const [credits, setCredits] = useState(25000); 
  const [researchPoints, setResearchPoints] = useState(0);
  const [turn, setTurn] = useState(1);
  const [selectedHex, setSelectedHex] = useState<string | null>(null);
  const [selectedPlanetIdx, setSelectedPlanetIdx] = useState(0);
  
  // Economy & Environment State
  const [inventory, setInventory] = useState<InventoryState>({ alloys: 2000, dilithium: 1000, biomatter: 5000 });
  const [market, setMarket] = useState<MarketState>(INITIAL_MARKET);
  const [weather, setWeather] = useState<WeatherPhenomenon[]>([]);
  
  // Diplomacy & Structures
  const [diplomacy, setDiplomacy] = useState<DiplomacyState>(INITIAL_DIPLOMACY);
  const [structures, setStructures] = useState<Structure[]>([]);
  const [showMarket, setShowMarket] = useState(false);
  const [showDiplomacy, setShowDiplomacy] = useState(false);
  const [showSystemMenu, setShowSystemMenu] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  // Auto Save State
  const [autoSaveFrequency, setAutoSaveFrequency] = useState(5);
  const [lastAutoSave, setLastAutoSave] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Core Game Data
  const [exploredHexes, setExploredHexes] = useState<Set<string>>(new Set());
  const [systemImages, setSystemImages] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [apiQuotaExceeded, setApiQuotaExceeded] = useState(false);
  
  const [camera, setCamera] = useState<CameraState>({ x: 0, y: 0 });
  const [techLevels, setTechLevels] = useState<TechLevelsState>({ Biotech: 0, Computers: 0, Construction: 0, Energy: 0, Propulsion: 0, Weapons: 0 });
  const [view, setView] = useState<'GALAXY' | 'RESEARCH'>('GALAXY');
  const [showMinimap, setShowMinimap] = useState(false);

  const [colonies, setColonies] = useState<ColonyMap>({});
  const [fleets, setFleets] = useState<Fleet[]>([]);
  const [galaxyData, setGalaxyData] = useState<GalaxyDataMap>({});

  const [selectedFleetId, setSelectedFleetId] = useState<string | null>(null);
  const [combatState, setCombatState] = useState<CombatState | null>(null);

  const keysPressed = useRef<{ [key: string]: boolean }>({});

  // Constants that rely on state now
  const DRAW_OFFSET_X = 800;
  const DRAW_OFFSET_Y = 800;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const createSaveState = (): SaveState => ({
      credits, researchPoints, turn, techLevels, colonies, fleets, camera, exploredHexes: Array.from(exploredHexes),
      autoSaveFrequency, timestamp: new Date().toISOString(), inventory, market, weather, diplomacy, structures, settings
  });

  const handleExitToMenu = () => {
      setGameState('MENU');
      setShowSystemMenu(false);
  };

  // Initialization Logic
  const initializeGame = () => {
      setLoading(true);
      // 1. Generate Galaxy
      const data: GalaxyDataMap = {};
      const reserved = new Set<string>();
      const CENTER_Q = Math.floor(settings.mapWidth / 2);
      const CENTER_R = Math.floor(settings.mapHeight / 2);

      // 1.1 Place Major Races
      const majorStarts: {id: number, hex: string}[] = [];
      MAJOR_RACES.forEach(race => {
          const q = Math.floor(race.relX * settings.mapWidth) - Math.floor(settings.mapHeight / 4);
          const r = Math.floor(race.relY * settings.mapHeight);
          const finalQ = Math.max(-Math.floor(settings.mapHeight/2), Math.min(settings.mapWidth, q));
          const finalR = Math.max(0, Math.min(settings.mapHeight, r));
          
          const hex = `${finalQ},${finalR}`;
          data[hex] = { 
              type: 'STAR', 
              name: race.id === 0 ? "Sol System" : `${race.homeworld} System`, 
              planets: race.id === 0 
                  ? SOL_PLANETS.map(p => ({ ...PLANET_TYPES[p.type], name: p.name, slots: p.slots, moons: p.moons })) 
                  : Array.from({ length: 5 }).map((_, i) => ({ ...PLANET_TYPES[Math.floor(pseudoRandom(race.id + i) * 3)], name: `Planet ${i + 1}`, slots: 8, moons: Math.floor(pseudoRandom(race.id + i + 100) * 3) })),
              label: race.id === 0 ? "SOL" : race.homeworld.toUpperCase(),
              raceBg: race.bgColor
          };
          reserved.add(hex);
          majorStarts.push({ id: race.id, hex });
      });

      // 1.2 Place Minor Races
      const minorStarts: {id: number, hex: string}[] = [];
      MINOR_RACES.forEach(race => {
          let placed = false;
          let attempts = 0;
          while(!placed && attempts < 200) {
              const q = Math.floor(Math.random() * settings.mapWidth) - Math.floor(settings.mapHeight / 4);
              const r = Math.floor(Math.random() * settings.mapHeight);
              const hex = `${q},${r}`;
              
              const tooCloseToMajors = majorStarts.some(m => getHexDistance(q, r, parseInt(m.hex.split(',')[0]), parseInt(m.hex.split(',')[1])) < 8);
              const tooCloseToMinors = minorStarts.some(m => getHexDistance(q, r, parseInt(m.hex.split(',')[0]), parseInt(m.hex.split(',')[1])) < 6);
              
              if (!reserved.has(hex) && !tooCloseToMajors && !tooCloseToMinors) {
                  data[hex] = {
                      type: 'STAR',
                      name: `${race.homeworld} System`,
                      label: race.name.toUpperCase(),
                      planets: [{ ...PLANET_TYPES[0], name: race.homeworld, slots: 10, moons: 1 }],
                      raceBg: race.bgColor,
                      minorRaceId: race.id
                  };
                  reserved.add(hex);
                  minorStarts.push({ id: race.id, hex });
                  placed = true;
              }
              attempts++;
          }
      });

      // 1.3 Place Center
      if (!reserved.has(`${CENTER_Q},${CENTER_R}`)) {
          data[`${CENTER_Q},${CENTER_R}`] = { type: 'BLACK_HOLE', name: 'Galactic Core', label: 'SAGITTARIUS A*', planets: [], raceBg: 'bg-white shadow-[0_0_50px_rgba(255,255,255,0.8)]' };
          reserved.add(`${CENTER_Q},${CENTER_R}`);
      }

      // 1.4 Procedural Fill
      const NUM_ARMS = 3; const ARM_WIDTH = 0.6; const TWIST_FACTOR = 0.15;
      for (let r = 0; r < settings.mapHeight; r++) {
        let r_offset = Math.floor(r / 2);
        for (let q = -r_offset; q < settings.mapWidth - r_offset; q++) {
            const id = `${q},${r}`;
            if (reserved.has(id)) continue;
            const dq = q - CENTER_Q; const dr = r - CENTER_R; const distance = Math.sqrt(dq*dq + dr*dr); const angle = Math.atan2(dr, dq);
            const seed = Math.abs(q * 12.34 + r * 56.78); const rng = pseudoRandom(seed);
            const twistedAngle = angle + distance * TWIST_FACTOR; const normalizedAngle = (twistedAngle % (2 * Math.PI) + (2 * Math.PI)) % (2 * Math.PI);
            let inArm = false; let armCenterDist = 100;
            for(let i=0; i<NUM_ARMS; i++) { const armCenterAngle = (i * 2 * Math.PI / NUM_ARMS); let diff = Math.abs(normalizedAngle - armCenterAngle); if (diff > Math.PI) diff = 2 * Math.PI - diff; if (diff < ARM_WIDTH) { inArm = true; armCenterDist = Math.min(armCenterDist, diff); } }
            
            let sysType: StarSystem['type'] | null = null; let hasSystem = false;
            if (distance < 5) { if (rng > 0.6) { sysType = rng > 0.85 ? 'NEUTRON_STAR' : rng > 0.75 ? 'ION_STORM' : 'STAR'; hasSystem = true; } }
            else if (inArm) { const armDensity = 0.45; if (rng < armDensity * (1 - armCenterDist)) { hasSystem = true; if (rng < 0.05) sysType = 'BINARY'; else if (rng < 0.08) sysType = 'HYPERGIANT'; else sysType = 'STAR'; } }
            else if (armCenterDist < ARM_WIDTH * 1.5) { if (rng < 0.15) { hasSystem = true; sysType = 'NEBULA'; if (rng < 0.02) sysType = 'PULSAR'; } }
            else { 
                if (rng < 0.08) { hasSystem = true; if (rng < 0.01) sysType = 'BLACK_HOLE'; else if (rng < 0.02) sysType = 'WORMHOLE'; else if (rng < 0.03) sysType = 'ROGUE_PLANET'; else if (rng < 0.04) sysType = 'DARK_MATTER'; else if (rng < 0.05) sysType = 'GRAVITON_ELLIPSE'; else if (rng < 0.06) sysType = 'BADLANDS'; else sysType = 'ASTEROID_FIELD'; } 
                else if (rng < 0.12) { 
                    hasSystem = true; 
                    const subRng = pseudoRandom(seed + 99);
                    if (subRng < 0.25) sysType = 'OCEANIC';
                    else if (subRng < 0.5) sysType = 'VOLCANIC';
                    else if (subRng < 0.75) sysType = 'ANCIENT';
                    else sysType = 'SHADOW';
                }
            }
            
            if (hasSystem && sysType) {
                let nameIdx = Math.floor(pseudoRandom(seed + 1) * SYSTEM_NAMES.length); let systemName = SYSTEM_NAMES[nameIdx]; let label = systemName.toUpperCase();
                if (sysType === 'BINARY') label += ' BINARY'; if (sysType === 'NEBULA') label += ' CLOUD'; if (sysType === 'ASTEROID_FIELD') label += ' BELT'; if (sysType === 'PULSAR') label += ' PULSAR';
                let planets: any[] = []; const planetCountSeed = pseudoRandom(seed + 5);
                
                if (['STAR', 'BINARY', 'HYPERGIANT'].includes(sysType)) { 
                    const count = Math.floor(planetCountSeed * 5) + 1; 
                    planets = Array.from({ length: count }).map((_, i) => { const pTypeIdx = Math.floor(pseudoRandom(seed + i + 10) * 6); return { ...PLANET_TYPES[pTypeIdx], name: `Planet ${i + 1}`, slots: Math.floor(pseudoRandom(seed + i) * 10) + 5, moons: Math.floor(pseudoRandom(seed + i + 55) * 3) }; }); 
                } 
                else if (sysType === 'NEBULA') { 
                    const count = Math.floor(planetCountSeed * 3) + 2; 
                    planets = Array.from({ length: count }).map((_, i) => { 
                        const isProtostar = pseudoRandom(seed + i) > 0.6;
                        if (isProtostar) return { ...PLANET_TYPES[12], name: `Protostar ${i+1}`, slots: 5, moons: 0 };
                        return { ...PLANET_TYPES[4], name: `Proto-Giant ${i + 1}`, slots: 8, moons: Math.floor(pseudoRandom(seed + i + 88) * 6) }; 
                    }); 
                } 
                else if (sysType === 'ROGUE_PLANET') { 
                    planets = [{ ...PLANET_TYPES[5], name: 'Lonely Wanderer', type: 'Rogue Planet', slots: 10, habitable: false, growthMod: 0, moons: 0 }]; 
                }
                else if (sysType === 'ASTEROID_FIELD') {
                    const count = Math.floor(planetCountSeed * 5) + 4;
                    planets = Array.from({ length: count }).map((_, i) => ({
                        ...PLANET_TYPES[6], 
                        name: `Asteroid ${String.fromCharCode(65+i)}`,
                        slots: 4,
                        moons: 0
                    }));
                }
                else if (sysType === 'NEUTRON_STAR') planets = [{ ...PLANET_TYPES[7], name: 'Neutron Star', slots: 0, moons: 0 }];
                else if (sysType === 'PULSAR') planets = [{ ...PLANET_TYPES[13], name: 'Pulsar Core', slots: 0, moons: 0 }];
                else if (sysType === 'BADLANDS' || sysType === 'ION_STORM') {
                    const count = Math.floor(planetCountSeed * 3) + 2;
                    planets = Array.from({ length: count }).map((_, i) => ({ ...PLANET_TYPES[8], name: `Plasma Eddy ${i+1}`, slots: 0, moons: 0 }));
                }
                else if (sysType === 'GRAVITON_ELLIPSE' || sysType === 'WHITE_HOLE') planets = [{ ...PLANET_TYPES[9], name: 'Spatial Anomaly', slots: 0, moons: 0 }];
                else if (sysType === 'DARK_MATTER') {
                    const count = Math.floor(planetCountSeed * 3) + 1;
                    planets = Array.from({ length: count }).map((_, i) => ({ ...PLANET_TYPES[10], name: `Dark Matter Node ${i+1}`, slots: 0, moons: 0 }));
                }
                else if (sysType === 'WORMHOLE') planets = [{ ...PLANET_TYPES[11], name: 'Wormhole Terminus', slots: 0, moons: 0 }];
                else if (sysType === 'BLACK_HOLE') planets = [{ ...PLANET_TYPES[9], name: 'Singularity', type: 'Singularity', color: 'bg-black', shadow: 'shadow-purple-500/100', desc: 'Infinite density', habitable: false, growthMod: 0, miningBonus: 'dilithium', slots: 0, moons: 0 }];
                else if (sysType === 'OCEANIC') {
                    const count = Math.floor(planetCountSeed * 4) + 2;
                    planets = Array.from({ length: count }).map((_, i) => {
                        const isSuper = pseudoRandom(seed + i) > 0.7;
                        if (isSuper) return { ...PLANET_TYPES[15], name: `Gaia ${i+1}`, slots: 12, moons: 2 };
                        return { ...PLANET_TYPES[19], name: `Thalassa ${i+1}`, slots: 10, moons: 1 };
                    });
                }
                else if (sysType === 'VOLCANIC') {
                    const count = Math.floor(planetCountSeed * 3) + 2;
                    planets = Array.from({ length: count }).map((_, i) => {
                        const isScorched = pseudoRandom(seed + i) > 0.5;
                        if (isScorched) return { ...PLANET_TYPES[18], name: `Inferno ${i+1}`, slots: 6, moons: 0 };
                        return { ...PLANET_TYPES[16], name: `Magma Prime ${i+1}`, slots: 8, moons: 0 };
                    });
                }
                else if (sysType === 'ANCIENT') {
                    const count = Math.floor(planetCountSeed * 2) + 2;
                    planets = Array.from({ length: count }).map((_, i) => {
                        const isMega = pseudoRandom(seed + i) > 0.5;
                        if (isMega) return { ...PLANET_TYPES[20], name: `Behemoth ${i+1}`, slots: 20, moons: 12 };
                        return { ...PLANET_TYPES[14], name: `Ringworld ${i+1}`, slots: 16, moons: 30 };
                    });
                }
                else if (sysType === 'SHADOW') {
                    const count = Math.floor(planetCountSeed * 3) + 1;
                    planets = Array.from({ length: count }).map((_, i) => {
                        return { ...PLANET_TYPES[17], name: `Umbra ${i+1}`, slots: 8, moons: 0 };
                    });
                }

                data[id] = { type: sysType, name: `${systemName} ${sysType}`, label, planets };
            }
        }
      }
      setGalaxyData(data);

      // 2. Initialize Colonies & Fleets
      const initialColonies: ColonyMap = {};
      const initialFleets: Fleet[] = [];
      const newExplored = new Set<string>();

      majorStarts.forEach(start => {
          const race = MAJOR_RACES.find(r => r.id === start.id);
          if (!race) return;
          const planetIdx = race.id === 0 ? 2 : 0; 
          initialColonies[start.hex] = { 
            [planetIdx]: { 
              buildings: ['power', 'factory', 'lab', 'shipyard'], 
              name: race.homeworld, 
              population: 10000,
              ownerId: race.id
            } 
          };
          initialFleets.push({
            id: `fleet-${race.id}-initial`,
            ownerId: race.id,
            hexId: start.hex,
            ships: [
              { uuid: `ship-${race.id}-1`, classId: 'scout', currentHull: 100, ownerId: race.id },
              { uuid: `ship-${race.id}-2`, classId: 'destroyer', currentHull: 300, ownerId: race.id }
            ],
            hasMoved: false,
            formation: 'standard'
          });
          
          if (race.id === 0) {
              newExplored.add(start.hex);
              const [q, r] = start.hex.split(',').map(Number);
              HEX_DIRECTIONS.forEach(([dq, dr]) => newExplored.add(`${q + dq},${r + dr}`));
              // Center camera
              const x = HEX_SIZE * (Math.sqrt(3) * q + (Math.sqrt(3) / 2) * r);
              const y = HEX_SIZE * (3 / 2 * r);
              setCamera({ x: -x + window.innerWidth/2 - DRAW_OFFSET_X, y: -y + window.innerHeight/2 - DRAW_OFFSET_Y });
          }
      });

      (Object.entries(data) as [string, StarSystem][]).forEach(([hex, sys]) => {
          if (sys.minorRaceId !== undefined) {
              initialColonies[hex] = {
                  0: {
                      buildings: ['power', 'factory', 'housing'],
                      name: sys.planets[0].name,
                      population: 5000,
                      ownerId: sys.minorRaceId
                  }
              };
              initialFleets.push({
                  id: `fleet-minor-${sys.minorRaceId}`,
                  ownerId: sys.minorRaceId,
                  hexId: hex,
                  ships: [{ uuid: `ship-minor-${sys.minorRaceId}`, classId: 'destroyer', currentHull: 300, ownerId: sys.minorRaceId }],
                  hasMoved: false,
                  formation: 'standard'
              });
          }
      });

      setColonies(initialColonies);
      setFleets(initialFleets);
      setExploredHexes(newExplored);
      
      const phenomena: WeatherPhenomenon[] = [];
      for(let i=0; i<12; i++) {
        phenomena.push({
            id: `weather-${i}`, type: Math.random() > 0.7 ? 'ION_STORM' : 'NEBULA',
            q: Math.floor(Math.random() * settings.mapWidth), r: Math.floor(Math.random() * settings.mapHeight),
            radius: Math.floor(Math.random() * 3) + 2, velocity: [Math.random() * 0.4 - 0.2, Math.random() * 0.4 - 0.2], name: `Phenomenon ${i}`
        });
      }
      setWeather(phenomena);

      setCredits(25000);
      setResearchPoints(0);
      setTurn(1);
      setInventory({ alloys: 2000, dilithium: 1000, biomatter: 5000 });
      setMarket(INITIAL_MARKET);
      setDiplomacy(INITIAL_DIPLOMACY);
      setStructures([]);

      setLoading(false);
      setGameState('PLAYING');
  };

  const saveGameWithPicker = async () => {
    const gameState = createSaveState();
    const performDownload = () => {
      const blob = new Blob([JSON.stringify(gameState, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `stellar_hegemony_turn_${turn}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast("Game Saved Successfully");
    };
    try {
      if ('showSaveFilePicker' in window) {
        try {
          const handle = await window.showSaveFilePicker({
            suggestedName: `stellar_hegemony_turn_${turn}.json`,
            types: [{ description: 'Stellar Hegemony Save Game', accept: { 'application/json': ['.json'] }, }],
          });
          const writable = await handle.createWritable();
          await writable.write(JSON.stringify(gameState, null, 2));
          await writable.close();
          showToast("Game Saved Successfully");
        } catch (err: any) {
          if (err.name === 'AbortError') return;
          performDownload();
        }
      } else {
        performDownload();
      }
    } catch (err) {
      console.error('Save failed', err);
    }
  };

  const loadGameWithPicker = async () => {
    const performUpload = () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.onchange = async (e: Event) => {
        const target = e.target as HTMLInputElement;
        const file = target.files?.[0];
        if (file) {
          const content = await file.text();
          applyLoadedData(JSON.parse(content));
        }
      };
      input.click();
    };
    try {
      if ('showOpenFilePicker' in window) {
        try {
          const handles = await window.showOpenFilePicker({
            types: [{ description: 'Stellar Hegemony Save Game', accept: { 'application/json': ['.json'] }, }],
            multiple: false
          });
          const file = await handles[0].getFile();
          const content = await file.text();
          applyLoadedData(JSON.parse(content));
        } catch (err: any) {
          if (err.name === 'AbortError') return;
          performUpload();
        }
      } else {
        performUpload();
      }
    } catch (err) {
      console.error('Load failed', err);
    }
  };

  const loadAutoSave = () => {
      const saved = localStorage.getItem('stellar_hegemony_autosave');
      if (saved) { try { applyLoadedData(JSON.parse(saved)); showToast("Auto-Save Loaded"); } catch (e) { console.error("Failed to load auto-save", e); showToast("Failed to load auto-save"); } } else { showToast("No Auto-Save Found"); }
  };

  const applyLoadedData = (data: SaveState) => {
    setLoading(true);
    setSettings(data.settings || { mapWidth: 80, mapHeight: 50, fogOfWar: true, difficulty: 'normal' });
    setCredits(data.credits);
    setResearchPoints(data.researchPoints);
    setTurn(data.turn);
    setTechLevels(data.techLevels);
    setColonies(data.colonies);
    setFleets(data.fleets || []);
    setCamera(data.camera);
    if (data.exploredHexes) setExploredHexes(new Set(data.exploredHexes));
    if (data.autoSaveFrequency) setAutoSaveFrequency(data.autoSaveFrequency);
    if (data.inventory) setInventory(data.inventory);
    if (data.market) setMarket(data.market);
    if (data.weather) setWeather(data.weather);
    if (data.diplomacy) setDiplomacy(data.diplomacy);
    if (data.structures) setStructures(data.structures);
    setGameState('PLAYING');
    setLoading(false);
  };

  // Influence Calculation
  const territories = useMemo(() => {
    const gridClaims: { [key: string]: number } = {};
    const influenceSources: {q: number, r: number, raceId: number, radius: number, strength: number}[] = [];

    // Colonies (Major + Minor)
    Object.entries(colonies).forEach(([hexId, planets]) => {
      const [q, r] = hexId.split(',').map(Number);
      const planetValues = Object.values(planets as { [key: number]: ColonyDetails });
      if (planetValues.length === 0) return;
      const ownerId = planetValues[0].ownerId;
      
      let systemPop = 0; let buildingBonus = 0;
      planetValues.forEach(p => { systemPop += (p.population || 0); p.buildings.forEach(bid => { const b = (Object.values(BUILDINGS).flat() as Building[]).find(o => o.id === bid); if (b?.influenceBonus) buildingBonus += b.influenceBonus; }); });
      
      const techBonus = Math.floor(techLevels.Construction / 2) + Math.floor(techLevels.Propulsion / 3);
      const isMinor = MINOR_RACES.some(m => m.id === ownerId);
      const radius = isMinor ? 2 : (1 + Math.floor(Math.log10(Math.max(100, systemPop) / 100)) + buildingBonus + techBonus);
      influenceSources.push({ q, r, raceId: ownerId, radius, strength: systemPop });
    });

    structures.forEach(s => {
        const [q, r] = s.hexId.split(',').map(Number);
        const radius = s.type === 'starbase' ? 2 : 1;
        const strength = s.type === 'starbase' ? 50000 : 10000; 
        influenceSources.push({ q, r, raceId: s.ownerId, radius, strength });
    });

    for (let r = 0; r < settings.mapHeight; r++) {
      let r_offset = Math.floor(r / 2);
      for (let q = -r_offset; q < settings.mapWidth - r_offset; q++) {
        let bestRace = -1; let bestWeight = -1;
        influenceSources.forEach(source => { const dist = getHexDistance(q, r, source.q, source.r); if (dist <= source.radius) { const weight = (source.radius - dist + 1) * source.strength; if (weight > bestWeight) { bestWeight = weight; bestRace = source.raceId; } } });
        if (bestRace !== -1) gridClaims[`${q},${r}`] = bestRace;
      }
    }
    return gridClaims;
  }, [colonies, techLevels, structures, settings.mapWidth, settings.mapHeight]);

  const economyStats = useMemo(() => {
    let rp = 0; let creds = 500; 
    let generatedInventory: InventoryState = { alloys: 0, dilithium: 0, biomatter: 0 };
    Object.entries(colonies).forEach(([hexId, planets]) => {
      Object.values(planets as { [key: number]: ColonyDetails }).forEach(col => {
        if (col.ownerId === 0) { 
          creds += (col.population || 0) * 0.1;
          const system = galaxyData[hexId];
          const planetData = system?.planets.find(p => p.name === col.name);
          if (planetData && planetData.miningBonus) { generatedInventory[planetData.miningBonus] += 10 + Math.floor(col.population / 100); }
          col.buildings.forEach(bid => { const b = (Object.values(BUILDINGS).flat() as Building[]).find(i => i.id === bid); if (b) { rp += b.rp || 0; creds += b.credits || 0; } });
        }
      });
    });
    // Add trade income
    (Object.values(diplomacy) as DiplomaticRelation[]).forEach(rel => {
        if (rel.status === 'trade') creds += 200;
        if (rel.status === 'ally') creds += 500;
    });
    
    return { rp: Math.floor(rp * (1 + techLevels.Computers * 0.1)), creds: Math.floor(creds * (1 + techLevels.Energy * 0.05)), generatedInventory };
  }, [colonies, techLevels, galaxyData, diplomacy]);

  const handleNextTurn = () => {
    setTurn(t => t + 1);
    setWeather(prev => prev.map(w => {
        let nextQ = w.q + w.velocity[0]; let nextR = w.r + w.velocity[1];
        if (nextQ < 0 || nextQ >= settings.mapWidth) w.velocity[0] *= -1;
        if (nextR < 0 || nextR >= settings.mapHeight) w.velocity[1] *= -1;
        return { ...w, q: Math.max(0, Math.min(settings.mapWidth - 1, nextQ)), r: Math.max(0, Math.min(settings.mapHeight - 1, nextR)) };
    }));
    setMarket(prev => {
        const next = { ...prev };
        Object.keys(next).forEach((key) => {
            const res = key as ResourceType; const item = next[res]; let fluctuation = (Math.random() - 0.5) * item.volatility;
            if (combatState?.active && res === 'alloys') fluctuation += 2; if (res === 'biomatter' && Math.random() > 0.7) fluctuation += 1;
            let newPrice = Math.max(1, item.price + fluctuation);
            next[res] = { price: newPrice, trend: newPrice > item.price ? 'up' : newPrice < item.price ? 'down' : 'stable', volatility: item.volatility };
        });
        return next;
    });
    setFleets(prev => {
        const nextFleets = prev.map(f => ({ ...f, hasMoved: false }));
        if (turn % 5 === 0) { 
             MAJOR_RACES.filter(r => r.id !== 0).forEach(race => {
                if (Math.random() < 0.3) {
                    const homeHex = Object.keys(colonies).find(h => Object.values(colonies[h]).some((c: ColonyDetails) => c.ownerId === race.id && c.name === race.homeworld));
                    if (homeHex) {
                        const shipClass = SHIP_CLASSES.find(c => c.id === 'cruiser')!; 
                        const newShip: Ship = { uuid: `ship-${race.id}-${Date.now()}-${Math.random()}`, classId: shipClass.id, currentHull: shipClass.hull, ownerId: race.id };
                        const fleetIdx = nextFleets.findIndex(f => f.ownerId === race.id && f.hexId === homeHex);
                        if (fleetIdx >= 0) { 
                            nextFleets[fleetIdx].ships.push(newShip); 
                        } else { 
                            nextFleets.push({ id: `fleet-${race.id}-${Date.now()}`, ownerId: race.id, hexId: homeHex, ships: [newShip], formation: 'standard', hasMoved: false }); 
                        }
                    }
                }
            });
        }
        return nextFleets;
    });
    setColonies(prev => {
      const next: ColonyMap = JSON.parse(JSON.stringify(prev));
      Object.keys(next).forEach(hexId => {
        if (!galaxyData[hexId]) return;
        Object.keys(next[hexId]).forEach(pIdxStr => {
            const pIdx = Number(pIdxStr); const col = next[hexId][pIdx]; const system = galaxyData[hexId];
            if (!system || !system.planets || !system.planets[pIdx]) return;
            const planetType = system.planets[pIdx];
            let growth = (BASE_GROWTH_RATE + (techLevels.Biotech * 0.02)) * planetType.growthMod;
            const cap = planetType.slots * 1000;
            if (col.population < cap) col.population = Math.min(cap, col.population + (col.population * growth));
        });
      });
      const aiRaces = MAJOR_RACES.filter(r => r.id !== 0);
      aiRaces.forEach(race => {
        if (Math.random() > 0.2) return;
        const ownedHexes = Object.entries(next).filter(([_, planets]) => Object.values(planets as { [key: number]: ColonyDetails }).some((p) => p.ownerId === race.id)).map(([hex, _]) => hex);
        if (ownedHexes.length === 0) return;
        const candidates: string[] = [];
        ownedHexes.forEach(hex => {
          const [q, r] = hex.split(',').map(Number);
          HEX_DIRECTIONS.forEach(([dq, dr]) => {
            const nQ = q + dq; const nR = r + dr; const nId = `${nQ},${nR}`;
            const sys = galaxyData[nId];
            if (sys && ['STAR', 'BINARY', 'HYPERGIANT'].includes(sys.type) && !next[nId]) { candidates.push(nId); }
          });
        });
        if (candidates.length > 0) {
          const targetHex = candidates[Math.floor(Math.random() * candidates.length)];
          const system = galaxyData[targetHex];
          if (system && system.planets) {
            const habitablePlanets = system.planets.map((p, idx) => ({ ...p, idx })).filter(p => p.habitable);
            if (habitablePlanets.length > 0) {
               const targetPlanet = habitablePlanets[Math.floor(Math.random() * habitablePlanets.length)];
               if (!next[targetHex]) next[targetHex] = {};
               next[targetHex][targetPlanet.idx] = { buildings: [], name: targetPlanet.name, population: 500, ownerId: race.id };
            }
          }
        }
      });
      return next;
    });
    setCredits(c => c + economyStats.creds); setResearchPoints(r => r + economyStats.rp); setInventory(prev => ({ alloys: prev.alloys + economyStats.generatedInventory.alloys, dilithium: prev.dilithium + economyStats.generatedInventory.dilithium, biomatter: prev.biomatter + economyStats.generatedInventory.biomatter }));
  };

  const handleBuildShip = (classId: string) => {
    if (!selectedHex) return; const shipClass = SHIP_CLASSES.find(s => s.id === classId); if (!shipClass) return;
    if (credits < shipClass.cost) { showToast("Insufficient Credits"); return; }
    if (inventory.alloys < (shipClass.resourceCost.alloys || 0)) { showToast("Insufficient Alloys"); return; }
    if (inventory.dilithium < (shipClass.resourceCost.dilithium || 0)) { showToast("Insufficient Dilithium"); return; }
    if (inventory.biomatter < (shipClass.resourceCost.biomatter || 0)) { showToast("Insufficient Biomatter"); return; }
    setCredits(c => c - shipClass.cost); setInventory(prev => ({ alloys: prev.alloys - (shipClass.resourceCost.alloys || 0), dilithium: prev.dilithium - (shipClass.resourceCost.dilithium || 0), biomatter: prev.biomatter - (shipClass.resourceCost.biomatter || 0) }));
    setFleets(prev => { const existingFleetIndex = prev.findIndex(f => f.hexId === selectedHex && f.ownerId === 0); const newShip: Ship = { uuid: `ship-0-${Date.now()}-${Math.random()}`, classId: shipClass.id, currentHull: shipClass.hull, ownerId: 0 }; if (existingFleetIndex >= 0) { const next = [...prev]; next[existingFleetIndex] = { ...next[existingFleetIndex], ships: [...next[existingFleetIndex].ships, newShip] }; return next; } else { return [...prev, { id: `fleet-0-${Date.now()}`, ownerId: 0, hexId: selectedHex, ships: [newShip], hasMoved: false, formation: 'standard' }]; } });
  };
  const handleFleetMove = (targetHexId: string) => {
    if (!selectedFleetId) return; const [tq, tr] = targetHexId.split(',').map(Number); const fleet = fleets.find(f => f.id === selectedFleetId); if (!fleet || fleet.hasMoved || fleet.ownerId !== 0) return; const [cq, cr] = fleet.hexId.split(',').map(Number); const dist = getHexDistance(cq, cr, tq, tr); if (dist > 1) return; 
    const completeMove = () => { setFleets(prev => prev.map(f => { if (f.id === selectedFleetId) { return { ...f, hexId: targetHexId, hasMoved: true }; } return f; })); if (!exploredHexes.has(targetHexId)) { setExploredHexes(prev => new Set(prev).add(targetHexId)); } };
    const enemyFleet = fleets.find(f => f.hexId === targetHexId && f.ownerId !== fleet.ownerId);
    if (enemyFleet) { const relations = diplomacy[enemyFleet.ownerId]; if (relations && relations.status === 'war') { setCombatState({ active: true, attackerId: fleet.id, defenderId: enemyFleet.id, hexId: targetHexId, round: 0, logs: [{ round: 0, message: "Hostile fleet intercepted! Battle stations!", type: 'damage' }] }); } else { completeMove(); showToast(`Moved into territory of ${[...MAJOR_RACES, ...MINOR_RACES].find(r => r.id === enemyFleet.ownerId)?.name || 'Unknown'}. No hostilities.`); } } else { completeMove(); }
  };
  const performColonize = (planetIdx: number) => { if (!selectedFleetId || !selectedHex) return; const fleet = fleets.find(f => f.id === selectedFleetId); if (!fleet) return; const colonyShipIndex = fleet.ships.findIndex(s => s.classId === 'colony_ship'); if (colonyShipIndex === -1) return; const system = galaxyData[selectedHex]; if (!system || !system.planets[planetIdx]) return; const p = system.planets[planetIdx]; setColonies(prev => ({ ...prev, [selectedHex]: { ...(prev[selectedHex] || {}), [planetIdx]: { buildings: [], name: p.name, population: 1000, ownerId: 0 } } })); const newShips = [...fleet.ships]; newShips.splice(colonyShipIndex, 1); setFleets(prev => { if (newShips.length === 0) return prev.filter(f => f.id !== fleet.id); return prev.map(f => f.id === fleet.id ? { ...f, ships: newShips } : f); }); showToast(`Colonized ${p.name}!`); };
  const performBuildStructure = (type: 'outpost' | 'starbase') => { if (!selectedFleetId || !selectedHex) return; const fleet = fleets.find(f => f.id === selectedFleetId); if (!fleet) return; const constShipIndex = fleet.ships.findIndex(s => s.classId === 'const_ship'); if (constShipIndex === -1) return; const cost = type === 'outpost' ? 2000 : 5000; if (credits < cost) { showToast("Insufficient Credits for Construction"); return; } setCredits(c => c - cost); setStructures(prev => [...prev, { id: `struct-${Date.now()}`, type, ownerId: 0, hexId: selectedHex }]); setFleets(prev => prev.map(f => f.id === fleet.id ? { ...f, hasMoved: true } : f)); showToast(`${type === 'outpost' ? 'Outpost' : 'Starbase'} Constructed!`); };
  
  const handleRetreat = () => {
    if (!combatState) return;
    const playerFleet = fleets.find(f => (f.id === combatState.attackerId || f.id === combatState.defenderId) && f.ownerId === 0);
    if (!playerFleet) { showToast("No fleet to retreat!"); return; }
    const [q, r] = combatState.hexId.split(',').map(Number);
    let retreatHex: string | null = null;
    for (const [dq, dr] of HEX_DIRECTIONS) {
        const nHex = `${q + dq},${r + dr}`;
        if (exploredHexes.has(nHex)) {
            const hasEnemy = fleets.some(f => f.hexId === nHex && f.ownerId !== 0);
            if (!hasEnemy) { retreatHex = nHex; break; }
        }
    }
    if (retreatHex) {
        setFleets(prev => prev.map(f => f.id === playerFleet.id ? { ...f, hexId: retreatHex!, hasMoved: true } : f));
        setCombatState(null);
        showToast("Fleet retreated to nearby sector!");
    } else {
        const anyNeighbor = HEX_DIRECTIONS.map(([dq, dr]) => `${q + dq},${r + dr}`).find(h => exploredHexes.has(h));
        if (anyNeighbor) {
             setFleets(prev => prev.map(f => f.id === playerFleet.id ? { ...f, hexId: anyNeighbor, hasMoved: true } : f));
             setCombatState(null);
             showToast("Emergency retreat executed!");
        } else {
             showToast("Retreat vector blocked! We are surrounded!");
        }
    }
  };

  const handleScrapFleet = () => {
    if (!selectedFleetId) return;
    const fleet = fleets.find(f => f.id === selectedFleetId);
    if (!fleet) return;
    let refund = 0;
    fleet.ships.forEach(s => { const cls = SHIP_CLASSES.find(c => c.id === s.classId); if (cls) refund += cls.cost * 0.5; });
    setCredits(c => c + refund);
    setFleets(prev => prev.filter(f => f.id !== selectedFleetId));
    setSelectedFleetId(null);
    showToast(`Fleet decommissioned. ${Math.floor(refund)}cr recovered.`);
  };

  const handleDiplomacyAction = (raceId: number, action: 'gift' | 'insult' | 'trade' | 'pact' | 'ally' | 'war' | 'peace') => {
      const rel = diplomacy[raceId] || { status: 'peace', opinion: 50 };
      let newRel = { ...rel };
      let msg = "";
      switch(action) {
          case 'gift':
              if (credits < 500) { showToast("Insufficient credits for gift."); return; }
              setCredits(c => c - 500); newRel.opinion = Math.min(100, newRel.opinion + 15); msg = "Gift sent. Relations improved."; break;
          case 'insult':
              newRel.opinion = Math.max(0, newRel.opinion - 15); if (newRel.opinion < 10 && newRel.status !== 'war') { newRel.status = 'hostile'; msg = "Insult sent. They are now hostile."; } else { msg = "Insult sent. Relations worsened."; } break;
          case 'trade':
              if (rel.status === 'war') { showToast("Cannot propose trade while at war."); return; } if (rel.opinion < 30) { showToast("They refuse our trade proposal."); return; } newRel.status = 'trade'; newRel.opinion += 5; msg = "Trade agreement established."; break;
          case 'pact':
              if (rel.status === 'war') { showToast("Cannot propose pact while at war."); return; } if (rel.opinion < 50) { showToast("They refuse the non-aggression pact."); return; } newRel.status = 'pact'; newRel.opinion += 10; msg = "Non-aggression pact signed."; break;
          case 'ally':
              if (rel.status === 'war') { showToast("Cannot propose alliance while at war."); return; } if (rel.status !== 'pact' && rel.status !== 'trade') { showToast("We need stronger ties first."); return; } if (rel.opinion < 80) { showToast("They are not ready for an alliance."); return; } newRel.status = 'ally'; newRel.opinion += 20; msg = "Alliance formed!"; break;
          case 'war':
              newRel.status = 'war'; newRel.opinion = 0; msg = "War declared!"; break;
          case 'peace':
              if (rel.status !== 'war') return; if (Math.random() > 0.5) { newRel.status = 'peace'; newRel.opinion = 10; msg = "Peace treaty signed."; } else { msg = "They refused our peace offer."; } break;
      }
      setDiplomacy(prev => ({ ...prev, [raceId]: newRel }));
      showToast(msg);
  };

  const resolveCombatRound = () => { if (!combatState) return; const attackerFleet = fleets.find(f => f.id === combatState.attackerId); const defenderFleet = fleets.find(f => f.id === combatState.defenderId); if (!attackerFleet || !defenderFleet) { setCombatState(null); return; } const newLogs: CombatLogEntry[] = []; let updatedAttacker = { ...attackerFleet }; let updatedDefender = { ...defenderFleet }; if (updatedAttacker.ownerId !== 0) { const bestForm = decideAIFormation(updatedAttacker, updatedDefender); if (bestForm !== updatedAttacker.formation) { updatedAttacker.formation = bestForm; newLogs.push({ round: combatState.round + 1, message: `Enemy fleet shifts to ${FORMATIONS[bestForm].name} formation!`, type: 'info' }); } } if (updatedDefender.ownerId !== 0) { const bestForm = decideAIFormation(updatedDefender, updatedAttacker); if (bestForm !== updatedDefender.formation) { updatedDefender.formation = bestForm; newLogs.push({ round: combatState.round + 1, message: `Enemy fleet shifts to ${FORMATIONS[bestForm].name} formation!`, type: 'info' }); } } const [hexQ, hexR] = combatState.hexId.split(',').map(Number); const activeWeather = weather.find(w => getHexDistance(hexQ, hexR, w.q, w.r) <= w.radius); if (activeWeather) { newLogs.push({ round: combatState.round + 1, message: `Combat affected by ${activeWeather.name} (${activeWeather.type})!`, type: 'info' }); } const attackerShips = [...updatedAttacker.ships]; const defenderShips = [...updatedDefender.ships]; const fireVolley = (sourceShips: Ship[], targetShips: Ship[], sourceOwnerId: number, isAttacker: boolean) => { sourceShips.forEach(ship => { if (targetShips.length === 0) return; const shipClass = SHIP_CLASSES.find(c => c.id === ship.classId)!; if (!shipClass.damage) return; const targetIndex = Math.floor(Math.random() * targetShips.length); const target = targetShips[targetIndex]; const targetClass = SHIP_CLASSES.find(c => c.id === target.classId)!; const tech = sourceOwnerId === 0 ? techLevels : { Weapons: 2, Energy: 2, Propulsion: 2, Biotech: 0, Computers: 0, Construction: 0 }; const targetTech = sourceOwnerId === 0 ? { Weapons: 2, Energy: 2, Propulsion: 2, Biotech: 0, Computers: 0, Construction: 0 } : techLevels; const myForm = isAttacker ? FORMATIONS[updatedAttacker.formation] : FORMATIONS[updatedDefender.formation]; const targetForm = isAttacker ? FORMATIONS[updatedDefender.formation] : FORMATIONS[updatedAttacker.formation]; let weatherAccMod = 1.0; let weatherEvaMod = 1.0; let weatherShieldMod = 1.0; if (activeWeather?.type === 'NEBULA') { weatherEvaMod = 1.5; weatherAccMod = 0.7; } if (activeWeather?.type === 'ION_STORM') { weatherShieldMod = 0; } const accuracy = shipClass.accuracy * (1 + (tech.Propulsion || 0) * 0.05) * myForm.modifiers.accuracy * weatherAccMod; const evasion = targetClass.evasion * (1 + (targetTech.Propulsion || 0) * 0.05) * targetForm.modifiers.evasion * weatherEvaMod; const hitChance = Math.max(0.1, Math.min(0.95, accuracy - evasion)); if (Math.random() < hitChance) { const dmgMult = (1 + (tech.Weapons || 0) * 0.1) * myForm.modifiers.damage; const shieldMult = (1 + (targetTech.Energy || 0) * 0.1) * targetForm.modifiers.defense * weatherShieldMod; const rawDmg = shipClass.damage * dmgMult; const mitigation = targetClass.shields * shieldMult * 0.2; const finalDmg = Math.max(1, Math.floor(rawDmg - mitigation)); target.currentHull -= finalDmg; newLogs.push({ round: combatState.round + 1, message: `${shipClass.name} hit ${targetClass.name} for ${finalDmg} damage!`, type: 'damage' }); if (target.currentHull <= 0) { targetShips.splice(targetIndex, 1); newLogs.push({ round: combatState.round + 1, message: `${targetClass.name} destroyed!`, type: 'kill' }); } } }); }; fireVolley(attackerShips, defenderShips, updatedAttacker.ownerId, true); fireVolley(defenderShips, attackerShips, updatedDefender.ownerId, false); setFleets(prev => prev.map(f => { if (f.id === updatedAttacker.id) return { ...f, ships: attackerShips, formation: updatedAttacker.formation }; if (f.id === updatedDefender.id) return { ...f, ships: defenderShips, formation: updatedDefender.formation }; return f; })); if (attackerShips.length === 0 || defenderShips.length === 0) { if (attackerShips.length > 0) { setFleets(prev => { const cleaned = prev.filter(f => f.ships.length > 0); return cleaned.map(f => f.id === updatedAttacker.id ? { ...f, hexId: combatState.hexId, hasMoved: true } : f); }); if (!exploredHexes.has(combatState.hexId)) { setExploredHexes(prev => new Set(prev).add(combatState.hexId)); } } else { setFleets(prev => prev.filter(f => f.ships.length > 0)); } setCombatState(null); } else { setCombatState(prev => prev ? { ...prev, round: prev.round + 1, logs: [...prev.logs, ...newLogs] } : null); } };
  const researchTech = (category: keyof TechLevelsState) => { const currentLvl = techLevels[category]; const cost = (currentLvl + 1) * 1000; if (researchPoints >= cost && currentLvl < TECH_TREE[category].levels.length) { setResearchPoints(r => r - cost); setTechLevels(prev => ({ ...prev, [category]: prev[category] + 1 })); } };
  const changeFormation = (fleetId: string, formationId: FormationId) => { setFleets(prev => prev.map(f => f.id === fleetId ? { ...f, formation: formationId } : f)); };
  const tradeResource = (res: ResourceType, action: 'buy' | 'sell', amount: number) => { const price = market[res].price; const total = price * amount; if (action === 'buy') { if (credits >= total) { setCredits(c => c - total); setInventory(prev => ({ ...prev, [res]: prev[res] + amount })); setMarket(prev => ({ ...prev, [res]: { ...prev[res], price: prev[res].price + (amount * 0.01), trend: 'up' } })); } } else { if (inventory[res] >= amount) { setCredits(c => c + total); setInventory(prev => ({ ...prev, [res]: prev[res] - amount })); setMarket(prev => ({ ...prev, [res]: { ...prev[res], price: Math.max(1, prev[res].price - (amount * 0.01)), trend: 'down' } })); } } };

  useEffect(() => { const loop = setInterval(() => { if (view !== 'GALAXY') return; setCamera(prev => { let dx = 0, dy = 0; if (keysPressed.current['w']) dy += MOVE_SPEED; if (keysPressed.current['s']) dy -= MOVE_SPEED; if (keysPressed.current['a']) dx += MOVE_SPEED; if (keysPressed.current['d']) dx -= MOVE_SPEED; return (dx || dy) ? { x: prev.x + dx, y: prev.y + dy } : prev; }); }, 16); const handleKeyDown = (e: KeyboardEvent) => { const key = e.key.toLowerCase(); keysPressed.current[key] = true; if (key === 'k') saveGameWithPicker(); if (key === 'l') loadGameWithPicker(); if (key === 'm') setShowMinimap(prev => !prev); }; const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key.toLowerCase()] = false; }; window.addEventListener('keydown', handleKeyDown); window.addEventListener('keyup', handleKeyUp); return () => { clearInterval(loop); window.removeEventListener('keydown', handleKeyDown); window.removeEventListener('keyup', handleKeyUp); }; }, [credits, researchPoints, turn, techLevels, colonies, camera, view, exploredHexes]);
  
  useEffect(() => {
    if (selectedHex && galaxyData[selectedHex] && !isGenerating && exploredHexes.has(selectedHex)) {
      if (apiQuotaExceeded) {
        if (!systemImages[selectedHex]) {
          const sysType = galaxyData[selectedHex].type;
          setSystemImages(prev => ({ ...prev, [selectedHex]: FALLBACK_IMAGES[sysType] || FALLBACK_IMAGES.DEFAULT }));
        }
        return;
      }
      const sys = galaxyData[selectedHex];
      if (!systemImages[selectedHex]) {
        const generateImage = async () => {
          setIsGenerating(true);
          let prompt = `A cinematic space view of ${sys.name}`;
          if (sys.type === 'BLACK_HOLE') prompt = 'Supermassive black hole, accretion disk, cinematic';
          try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash-image', contents: { parts: [{ text: prompt }] }, config: { imageConfig: { aspectRatio: '16:9' } } });
            const candidate = response.candidates?.[0];
            if (candidate?.content?.parts?.[0]?.inlineData) {
              setSystemImages(prev => ({ ...prev, [selectedHex]: `data:${candidate.content.parts[0].inlineData.mimeType};base64,${candidate.content.parts[0].inlineData.data}` }));
            }
          } catch (err: any) {
             if (err.message?.includes('429') || err.status === 429 || (err.error && err.error.code === 429)) {
              setApiQuotaExceeded(true);
            }
            setSystemImages(prev => ({ ...prev, [selectedHex]: FALLBACK_IMAGES[sys.type] || FALLBACK_IMAGES.DEFAULT }));
          } finally {
            setIsGenerating(false);
          }
        };
        generateImage();
      }
    }
  }, [selectedHex, galaxyData, systemImages, isGenerating, apiQuotaExceeded, exploredHexes]);

  useEffect(() => { const timer = setTimeout(() => setLoading(false), 800); return () => clearTimeout(timer); }, []);

  const currentSystem = selectedHex ? galaxyData[selectedHex] : null;
  const currentPlanet = currentSystem?.planets?.[selectedPlanetIdx];
  const colonyData = colonies[selectedHex || '']?.[selectedPlanetIdx];
  const colonyOwnerId = colonyData?.ownerId;
  const hasShipyard = colonyData?.buildings.includes('shipyard');
  const selectedFleet = fleets.find(f => f.id === selectedFleetId);
  const isPlayerFleet = selectedFleet?.ownerId === 0;
  const activeWeather = useMemo(() => { if (!selectedHex) return null; const [q, r] = selectedHex.split(',').map(Number); return weather.find(w => getHexDistance(q, r, w.q, w.r) <= w.radius); }, [selectedHex, weather]);

  // Minimap
  const MINIMAP_WIDTH = 280; const MINIMAP_HEIGHT = 160; const WORLD_WIDTH_PX = settings.mapWidth * HEX_SIZE * Math.sqrt(3); const WORLD_HEIGHT_PX = settings.mapHeight * HEX_SIZE * 1.5; const minimapX = (worldX: number) => ((worldX) / (WORLD_WIDTH_PX + DRAW_OFFSET_X * 2)) * MINIMAP_WIDTH; const minimapY = (worldY: number) => ((worldY) / (WORLD_HEIGHT_PX + DRAW_OFFSET_Y * 2)) * MINIMAP_HEIGHT;

  if (loading) return <div className="h-screen w-full bg-black flex items-center justify-center"><div className="flex flex-col items-center gap-4"><div className="animate-spin text-blue-500"><Aperture size={48} /></div><div className="text-blue-500 font-bold uppercase tracking-[0.3em] text-sm animate-pulse">Computing Galactic Topology...</div></div></div>;

  // --- MAIN MENU RENDER ---
  if (gameState === 'MENU') {
      return (
          <div className="h-screen w-full bg-black flex relative overflow-hidden font-sans">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1475274047050-1d0c0975c63e?q=80&w=2672&auto=format&fit=crop')] bg-cover bg-center opacity-40"></div>
              <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
              
              <div className="z-10 flex flex-col justify-center px-24 w-1/2 h-full">
                  <div className="mb-12">
                      <div className="flex items-center gap-4 mb-2 text-blue-500 animate-pulse">
                          <Aperture size={48} />
                          <div className="h-px bg-blue-500/50 flex-grow"></div>
                      </div>
                      <h1 className="text-7xl font-black text-white italic tracking-tighter uppercase mb-4 drop-shadow-[0_0_15px_rgba(59,130,246,0.5)]">Stellar<br/>Hegemony</h1>
                      <p className="text-blue-400 font-bold uppercase tracking-[0.4em] text-sm">Birth of the Federation</p>
                  </div>

                  <div className="space-y-8 max-w-md">
                      {/* Map Size Selection */}
                      <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2"><Globe size={12}/> Galaxy Size</label>
                          <div className="flex gap-2">
                              {[
                                  { label: 'Small', w: 40, h: 25 },
                                  { label: 'Medium', w: 60, h: 40 },
                                  { label: 'Large', w: 80, h: 50 },
                              ].map(opt => (
                                  <button
                                      key={opt.label}
                                      onClick={() => setSettings(s => ({ ...s, mapWidth: opt.w, mapHeight: opt.h }))}
                                      className={`flex-1 py-4 rounded-xl border border-white/10 font-bold uppercase text-xs transition-all ${settings.mapWidth === opt.w ? 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] scale-105' : 'bg-slate-900/50 text-slate-500 hover:bg-slate-800'}`}
                                  >
                                      {opt.label}
                                  </button>
                              ))}
                          </div>
                      </div>

                      {/* Fog of War Toggle */}
                      <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2"><EyeOff size={12}/> Fog of War</label>
                          <button
                              onClick={() => setSettings(s => ({ ...s, fogOfWar: !s.fogOfWar }))}
                              className={`w-full py-4 rounded-xl border border-white/10 font-bold uppercase text-xs transition-all flex items-center justify-center gap-2 ${settings.fogOfWar ? 'bg-emerald-900/50 text-emerald-400 border-emerald-500/30' : 'bg-red-900/50 text-red-400 border-red-500/30'}`}
                          >
                              {settings.fogOfWar ? 'Enabled' : 'Disabled'}
                          </button>
                      </div>

                      <div className="h-px bg-white/10 w-full my-6"></div>

                      <div className="flex gap-4">
                          <button 
                              onClick={initializeGame}
                              className="flex-grow bg-blue-600 hover:bg-blue-500 text-white font-black uppercase text-sm py-5 rounded-xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-3 group"
                          >
                              <Play size={18} className="fill-current group-hover:scale-110 transition-transform"/> Engage
                          </button>
                          <button 
                              onClick={loadGameWithPicker}
                              className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold uppercase text-xs px-6 rounded-xl border border-white/10 transition-all flex flex-col items-center justify-center gap-1"
                          >
                              <HardDrive size={14}/> Load
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      );
  }

  // --- GAME RENDER ---
  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-200 overflow-hidden font-sans select-none">
      {toastMessage && <div className="fixed top-24 left-1/2 transform -translate-x-1/2 bg-blue-600/90 text-white px-6 py-3 rounded-full shadow-[0_0_20px_rgba(59,130,246,0.5)] z-[9999] font-black uppercase tracking-widest text-xs animate-in fade-in slide-in-from-top-4 duration-300">{toastMessage}</div>}

      {/* HEADER */}
      <div className="h-16 bg-black border-b border-blue-900/60 flex items-center justify-between px-6 z-50 shadow-2xl shrink-0 relative">
        <div className="flex items-center gap-10">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20"><Aperture size={24} className="text-white" /></div>
             <div>
               <div className="text-blue-400 font-black italic text-lg leading-tight">STELLAR HEGEMONY</div>
               <div className="text-[9px] text-blue-700 font-bold tracking-[0.4em]">SOVEREIGNTY & DEMOGRAPHICS</div>
             </div>
           </div>
           
           <div className="flex gap-8">
             <div className="flex flex-col">
               <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Imperial Treasury</span>
               <span className="text-yellow-500 font-black tabular-nums text-lg">₵ {credits.toLocaleString()}</span>
             </div>
             <div className="flex flex-col">
               <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Research Data</span>
               <span className="text-cyan-400 font-black flex items-center gap-1.5 tabular-nums text-lg"><Microscope size={14}/> {researchPoints.toLocaleString()}</span>
             </div>
             
             <div className="flex gap-4 border-l border-white/10 pl-6 cursor-pointer hover:bg-white/5 p-1 rounded transition-colors" onClick={() => setShowMarket(true)}>
                {Object.keys(inventory).map(key => {
                    const res = key as ResourceType; const Icon = RESOURCE_CONFIG[res].icon;
                    return (
                        <div key={res} className="flex flex-col">
                            <span className={`text-[9px] font-bold uppercase tracking-widest ${RESOURCE_CONFIG[res].color}`}>{res}</span>
                            <div className="flex items-center gap-1"><Icon size={12} className={RESOURCE_CONFIG[res].color}/><span className="font-bold tabular-nums text-sm">{Math.floor(inventory[res]).toLocaleString()}</span></div>
                        </div>
                    );
                })}
             </div>
           </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/50 p-1 rounded-xl border border-white/5">
          <button onClick={() => setView('GALAXY')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${view === 'GALAXY' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}>Galaxy</button>
          <button onClick={() => setView('RESEARCH')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${view === 'RESEARCH' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}>Technology</button>
          <button onClick={() => setShowDiplomacy(true)} className="px-4 py-2 rounded-lg text-slate-500 hover:text-white hover:bg-slate-800 transition-all flex items-center gap-2 border-l border-white/10 ml-2">
              <Handshake size={14}/>
              <span className="text-[10px] font-black uppercase tracking-widest">Diplomacy</span>
          </button>
        </div>

        <div className="flex items-center gap-4">
           <div className="text-right mr-4"><div className="text-[9px] text-slate-500 font-bold uppercase">Stardate</div><div className="text-blue-400 font-black">2370.{turn}</div></div>
           <button onClick={() => setShowHelp(true)} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors" title="Controls"><Info size={20}/></button>
           <button onClick={() => setShowSystemMenu(true)} className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"><Settings size={20}/></button>
           <button onClick={handleNextTurn} className="bg-blue-700 hover:bg-blue-600 px-8 py-3 rounded-lg border border-blue-400/30 font-black uppercase text-[11px] tracking-widest shadow-lg active:scale-95 transition-all">End Segment</button>
        </div>
      </div>

      <div className="flex-grow relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black">
        
        {view === 'GALAXY' ? (
          <>
            {/* HEX GRID */}
            <div className="absolute transition-transform duration-100 ease-out will-change-transform" style={{ transform: `translate(${camera.x}px, ${camera.y}px)` }}>
              {Array.from({ length: settings.mapHeight }).map((_, r) => {
                let r_offset = Math.floor(r / 2);
                return Array.from({ length: settings.mapWidth }).map((_, q_raw) => {
                  const q = q_raw - r_offset;
                  const hexId = `${q},${r}`;
                  const x = HEX_SIZE * (Math.sqrt(3) * q + (Math.sqrt(3) / 2) * r);
                  const y = HEX_SIZE * (3 / 2 * r);
                  const system = galaxyData[hexId];
                  const claimedBy = territories[hexId];
                  const isExplored = !settings.fogOfWar || exploredHexes.has(hexId);
                  const isSelected = selectedHex === hexId;
                  const activeWeather = weather.find(w => getHexDistance(q, r, w.q, w.r) <= w.radius);
                  const hasColony = colonies[hexId] && Object.keys(colonies[hexId]).length > 0;
                  const colonyOwnerId = hasColony ? (Object.values(colonies[hexId])[0] as ColonyDetails).ownerId : null;
                  const ownerRace = colonyOwnerId !== null ? [...MAJOR_RACES, ...MINOR_RACES].find(r => r.id === colonyOwnerId) : null;
                  const fleetInHex = fleets.find(f => f.hexId === hexId);
                  const isInNebula = activeWeather?.type === 'NEBULA';
                  const fleetOwner = fleetInHex ? [...MAJOR_RACES, ...MINOR_RACES].find(r => r.id === fleetInHex.ownerId) : null;
                  const showFleet = fleetInHex && (isExplored || fleetOwner?.id === 0);
                  const isUnknownSignal = showFleet && isInNebula && fleetOwner?.id !== 0;
                  const structureInHex = structures.find(s => s.hexId === hexId);

                  return (
                    <div 
                        key={hexId} 
                        onClick={() => setSelectedHex(hexId)}
                        onContextMenu={(e) => { e.preventDefault(); handleFleetMove(hexId); }}
                        className="absolute cursor-pointer group" 
                        style={{ left: x + DRAW_OFFSET_X, top: y + DRAW_OFFSET_Y, width: HEX_SIZE * 1.8, height: HEX_SIZE * 2 }}
                    >
                      <svg viewBox="0 0 100 115" className={`w-full h-full stroke-[1.5] transition-all duration-300 ${isSelected ? 'stroke-blue-400 stroke-[4px] drop-shadow-[0_0_8px_rgba(59,130,246,0.5)]' : 'stroke-white/10 group-hover:stroke-white/30'}`}>
                        {system?.type === 'BLACK_HOLE' ? (
                           <polygon points="50,0 100,28 100,86 50,115 0,86 0,28" className="fill-black stroke-purple-500 stroke-[3px]" style={{ filter: 'drop-shadow(0 0 15px rgba(168,85,247,0.8))' }} />
                        ) : (
                           <polygon points="50,0 100,28 100,86 50,115 0,86 0,28" className={`${isExplored ? '' : 'fill-slate-950/80'} transition-colors duration-1000`} style={{ fill: isExplored && claimedBy !== undefined ? [...MAJOR_RACES, ...MINOR_RACES].find(r => r.id === claimedBy)?.hexColor : undefined }} />
                        )}
                        {activeWeather && <polygon points="50,0 100,28 100,86 50,115 0,86 0,28" className={`pointer-events-none transition-opacity duration-1000 ${activeWeather.type === 'NEBULA' ? 'fill-purple-500/30' : 'fill-cyan-400/20 animate-pulse'}`} />}
                        {!isExplored && <polygon points="50,0 100,28 100,86 50,115 0,86 0,28" className="stroke-white/5 fill-[url(#fog-pattern)] pointer-events-none" />}
                      </svg>
                      
                      {/* Structure Icon */}
                      {isExplored && structureInHex && (
                          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                              {structureInHex.type === 'starbase' 
                                ? <Anchor size={16} className={`${MAJOR_RACES.find(r => r.id === structureInHex.ownerId)?.color} drop-shadow-[0_0_5px_rgba(0,0,0,1)]`}/> 
                                : <RadioTower size={12} className={`${MAJOR_RACES.find(r => r.id === structureInHex.ownerId)?.color} drop-shadow-[0_0_5px_rgba(0,0,0,1)]`}/>}
                          </div>
                      )}

                      {system && isExplored && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none animate-discover">
                          {renderSystemIcon(system.type, system.raceBg)}
                          <div className="absolute bottom-3 w-full flex flex-col items-center justify-center gap-1 pointer-events-none z-20">
                              <div className={`px-3 py-1 rounded-full flex items-center gap-2 border ${isSelected ? 'bg-blue-950/80 border-blue-400 text-blue-100' : 'bg-slate-950/70 border-white/10 text-slate-200'} backdrop-blur-md shadow-lg transition-all group-hover:scale-110`}>
                                  {hasColony && ownerRace && ( <Flag size={8} className={ownerRace.color} fill="currentColor" /> )}
                                  <span className="text-[9px] font-black tracking-[0.15em] uppercase whitespace-nowrap drop-shadow-md">{system.label}</span>
                              </div>
                          </div>
                        </div>
                      )}

                      {showFleet && (
                             <div className={`absolute top-0 right-0 z-10 pointer-events-auto transition-transform hover:scale-125 ${selectedFleetId === fleetInHex.id ? 'scale-125' : ''}`} onClick={(e) => { e.stopPropagation(); setSelectedFleetId(fleetInHex.id); }}>
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 22L12 18L22 22L12 2Z" className={`${isUnknownSignal ? 'fill-gray-500 stroke-gray-300' : `fill-${fleetOwner?.color.split('-')[1]}-600 stroke-white`} stroke-2`} /></svg>
                             </div>
                      )}
                    </div>
                  );
                });
              })}
            </div>
          </>
        ) : (
          /* TECHNOLOGY SCREEN */
          <div className="p-12 overflow-y-auto h-full pb-32">
              <h2 className="text-4xl font-black mb-12 flex items-center gap-4 text-blue-400 uppercase tracking-tighter"><Microscope size={40}/> Imperial Science Division</h2>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-8">
                  {(Object.entries(TECH_TREE) as [string, TechLevel][]).map(([key, data]) => {
                      const category = key as keyof TechLevelsState;
                      const currentLvl = techLevels[category];
                      const cost = (currentLvl + 1) * 1000;
                      const Icon = data.icon;
                      
                      return (
                          <div key={key} className="bg-slate-900/80 border border-white/10 rounded-2xl p-6 relative overflow-hidden group hover:border-blue-500/50 transition-all">
                              <div className={`absolute -right-12 -top-12 opacity-5 pointer-events-none transition-transform group-hover:scale-110 group-hover:opacity-10 ${data.color}`}><Icon size={200} /></div>
                              <div className="flex items-center gap-4 mb-6">
                                  <div className={`p-3 rounded-xl bg-slate-950 border border-white/10 ${data.color}`}><Icon size={24} /></div>
                                  <div>
                                      <h3 className={`text-xl font-black uppercase tracking-widest ${data.color}`}>{key}</h3>
                                      <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">Level {currentLvl}</div>
                                  </div>
                              </div>
                              
                              <div className="space-y-4 relative z-10">
                                  <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider text-slate-400">
                                      <span>Current Tech:</span>
                                      <span className="text-white">{data.levels[Math.min(currentLvl, data.levels.length - 1)]}</span>
                                  </div>
                                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                                      <div className={`h-full ${data.color.replace('text', 'bg')}`} style={{ width: `${(currentLvl / data.levels.length) * 100}%` }}></div>
                                  </div>
                                  
                                  {currentLvl < data.levels.length ? (
                                      <button 
                                          onClick={() => researchTech(category)}
                                          disabled={researchPoints < cost}
                                          className={`w-full py-4 rounded-xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all ${researchPoints >= cost ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg' : 'bg-slate-800 text-slate-600 cursor-not-allowed'}`}
                                      >
                                          {researchPoints >= cost ? <Microscope size={14}/> : <div className="animate-pulse bg-slate-700 w-3 h-3 rounded-full"></div>}
                                          Research Next ({cost} RP)
                                      </button>
                                  ) : (
                                      <div className="w-full py-4 rounded-xl bg-emerald-900/20 border border-emerald-500/30 text-emerald-400 font-black uppercase text-xs tracking-widest text-center">Tech Tree Maxed</div>
                                  )}
                              </div>
                          </div>
                      );
                  })}
              </div>
          </div>
        )}

        {/* --- UI OVERLAYS --- */}
        
        {/* HELP MODAL */}
        {showHelp && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-4" onClick={() => setShowHelp(false)}>
                <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 w-full max-w-lg shadow-2xl relative" onClick={e => e.stopPropagation()}>
                    <button onClick={() => setShowHelp(false)} className="absolute top-4 right-4 text-slate-500 hover:text-white"><X/></button>
                    <h2 className="text-2xl font-black uppercase tracking-tighter text-white mb-6 flex items-center gap-3"><Info className="text-blue-400"/> Command Protocols</h2>
                    
                    <div className="space-y-4">
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <span className="text-slate-400 font-bold uppercase text-xs tracking-wider">Camera Pan</span>
                            <span className="font-mono bg-slate-800 px-2 py-1 rounded text-blue-300 font-bold">W A S D</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <span className="text-slate-400 font-bold uppercase text-xs tracking-wider">Fleet Move</span>
                            <span className="font-mono bg-slate-800 px-2 py-1 rounded text-blue-300 font-bold">Right Click</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <span className="text-slate-400 font-bold uppercase text-xs tracking-wider">Select Object</span>
                            <span className="font-mono bg-slate-800 px-2 py-1 rounded text-blue-300 font-bold">Left Click</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <span className="text-slate-400 font-bold uppercase text-xs tracking-wider">Quick Save</span>
                            <span className="font-mono bg-slate-800 px-2 py-1 rounded text-blue-300 font-bold">K</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <span className="text-slate-400 font-bold uppercase text-xs tracking-wider">Quick Load</span>
                            <span className="font-mono bg-slate-800 px-2 py-1 rounded text-blue-300 font-bold">L</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <span className="text-slate-400 font-bold uppercase text-xs tracking-wider">Toggle Minimap</span>
                            <span className="font-mono bg-slate-800 px-2 py-1 rounded text-blue-300 font-bold">M</span>
                        </div>
                    </div>
                    
                    <div className="mt-8 text-center">
                        <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">United Federation of Planets • Starfleet Command</p>
                    </div>
                </div>
            </div>
        )}
        
        {/* SYSTEM MENU */}
        {showSystemMenu && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center">
                <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 w-96 shadow-2xl space-y-4">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-black uppercase tracking-tighter text-white">System Access</h2>
                        <button onClick={() => setShowSystemMenu(false)} className="text-slate-500 hover:text-white"><X/></button>
                    </div>
                    
                    <button onClick={() => { saveGameWithPicker(); setShowSystemMenu(false); }} className="w-full bg-slate-800 hover:bg-blue-900/50 border border-white/5 hover:border-blue-500/50 p-4 rounded-xl flex items-center gap-4 group transition-all">
                        <div className="bg-blue-500/20 p-2 rounded-lg text-blue-400 group-hover:text-white group-hover:bg-blue-500"><Save size={20}/></div>
                        <div className="text-left">
                            <div className="font-bold text-slate-200 group-hover:text-white">Save Game</div>
                            <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Store Current State</div>
                        </div>
                    </button>

                    <button onClick={() => { loadGameWithPicker(); setShowSystemMenu(false); }} className="w-full bg-slate-800 hover:bg-emerald-900/50 border border-white/5 hover:border-emerald-500/50 p-4 rounded-xl flex items-center gap-4 group transition-all">
                        <div className="bg-emerald-500/20 p-2 rounded-lg text-emerald-400 group-hover:text-white group-hover:bg-emerald-500"><HardDrive size={20}/></div>
                        <div className="text-left">
                            <div className="font-bold text-slate-200 group-hover:text-white">Load Game</div>
                            <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Retrieve Data</div>
                        </div>
                    </button>

                    <div className="h-px bg-white/10 my-2"></div>

                    <button onClick={handleExitToMenu} className="w-full bg-slate-800 hover:bg-red-900/50 border border-white/5 hover:border-red-500/50 p-4 rounded-xl flex items-center gap-4 group transition-all">
                        <div className="bg-red-500/20 p-2 rounded-lg text-red-400 group-hover:text-white group-hover:bg-red-500"><LogOut size={20}/></div>
                        <div className="text-left">
                            <div className="font-bold text-slate-200 group-hover:text-white">Exit to Menu</div>
                            <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">End Session</div>
                        </div>
                    </button>
                </div>
            </div>
        )}
        
        {/* LEFT PANEL - SYSTEM VIEW 3D */}
        {selectedHex && currentSystem && (
          <div className="absolute left-0 top-0 bottom-0 w-96 bg-black/95 border-r border-white/10 backdrop-blur-xl z-40 shadow-2xl animate-in slide-in-from-left duration-300 flex flex-col">
              <div className="p-4 border-b border-white/10 bg-slate-900/50 flex justify-between items-center">
                   <div className="flex items-center gap-2 text-blue-400">
                       <ScanEye size={20}/>
                       <h3 className="font-black uppercase tracking-widest text-sm">System View</h3>
                   </div>
                   <div className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Live Feed</div>
              </div>
              <div className="flex-1 relative bg-black">
                  <SystemView system={currentSystem} />
                  <div className="absolute bottom-4 left-4 right-4 pointer-events-none">
                      <div className="bg-black/60 backdrop-blur-md p-3 rounded-lg border border-white/10 text-center">
                          <p className="text-[9px] text-slate-400 uppercase tracking-widest mb-1">Navigation Control</p>
                          <p className="text-xs text-white font-bold">Drag to Rotate • Auto-Orbit</p>
                      </div>
                  </div>
              </div>
          </div>
        )}

        {/* RIGHT PANEL - SELECTION DETAILS */}
        {selectedHex && (
          <div className="absolute right-0 top-0 bottom-0 w-96 bg-black/95 border-l border-white/10 backdrop-blur-xl p-6 overflow-y-auto z-40 shadow-2xl animate-in slide-in-from-right duration-300">
             <button onClick={() => setSelectedHex(null)} className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors"><X size={20}/></button>
             
             {currentSystem ? (
                <div className="space-y-8">
                    {/* Header Image */}
                    <div className="relative aspect-video rounded-xl overflow-hidden shadow-2xl border border-white/10 group">
                        {systemImages[selectedHex] ? (
                            <img src={systemImages[selectedHex]} alt={currentSystem.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                        ) : (
                            <div className="w-full h-full bg-slate-900 animate-pulse flex items-center justify-center"><Aperture className="animate-spin text-slate-700"/></div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                        <div className="absolute bottom-4 left-4">
                            <h2 className="text-2xl font-black uppercase tracking-tighter text-white drop-shadow-md">{currentSystem.name}</h2>
                            <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-blue-400">{currentSystem.type.replace('_', ' ')}</div>
                        </div>
                    </div>

                    {/* Planet Selection */}
                    {currentSystem.planets.length > 0 && (
                        <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
                            {currentSystem.planets.map((p, idx) => (
                                <button 
                                    key={idx} 
                                    onClick={() => setSelectedPlanetIdx(idx)}
                                    className={`flex-shrink-0 w-16 h-16 rounded-xl border-2 transition-all relative overflow-hidden ${selectedPlanetIdx === idx ? 'border-blue-500 scale-105 shadow-[0_0_15px_rgba(59,130,246,0.5)]' : 'border-white/10 hover:border-white/30 bg-slate-900'}`}
                                >
                                    <div className={`absolute inset-0 ${p.color} opacity-20`}></div>
                                    <div className="absolute inset-0 flex items-center justify-center font-black text-xs">{idx + 1}</div>
                                </button>
                            ))}
                        </div>
                    )}

                    {currentPlanet && (
                        <div className="space-y-6">
                            <div className="bg-slate-900/50 rounded-xl p-4 border border-white/5 space-y-4">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="text-lg font-bold text-white">{currentPlanet.name}</h3>
                                        <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">{currentPlanet.type}</div>
                                    </div>
                                    <div className={`w-3 h-3 rounded-full ${currentPlanet.color} shadow-[0_0_10px_currentColor]`}></div>
                                </div>
                                <p className="text-xs text-slate-400 leading-relaxed italic">{currentPlanet.desc}</p>
                                
                                <div className="grid grid-cols-2 gap-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                    <div className="bg-black/30 p-2 rounded flex justify-between"><span>Slots</span> <span className="text-white">{currentPlanet.slots}</span></div>
                                    <div className="bg-black/30 p-2 rounded flex justify-between"><span>Moons</span> <span className="text-white">{currentPlanet.moons}</span></div>
                                    <div className="bg-black/30 p-2 rounded flex justify-between"><span>Habitable</span> <span className={currentPlanet.habitable ? "text-emerald-400" : "text-red-400"}>{currentPlanet.habitable ? 'Yes' : 'No'}</span></div>
                                    {currentPlanet.miningBonus && <div className="bg-black/30 p-2 rounded flex justify-between"><span>Resource</span> <span className={RESOURCE_CONFIG[currentPlanet.miningBonus].color}>{currentPlanet.miningBonus}</span></div>}
                                </div>
                            </div>

                            {/* Colony Management */}
                            {colonyData ? (
                                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                                    <div className="flex items-center gap-3 text-emerald-400 bg-emerald-950/30 p-3 rounded-xl border border-emerald-500/20">
                                        <Flag size={16}/>
                                        <span className="font-bold uppercase text-xs tracking-wider">Colony Established</span>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-slate-900 p-3 rounded-xl border border-white/5">
                                            <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Population</div>
                                            <div className="text-lg font-black tabular-nums">{colonyData.population.toLocaleString()}</div>
                                        </div>
                                        <div className="bg-slate-900 p-3 rounded-xl border border-white/5">
                                            <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Owner</div>
                                            <div className="text-lg font-black">{colonyOwnerId === 0 ? 'UFP' : [...MAJOR_RACES, ...MINOR_RACES].find(r => r.id === colonyOwnerId)?.name || 'Alien'}</div>
                                        </div>
                                    </div>

                                    {colonyOwnerId === 0 && (
                                        <>
                                            <div className="space-y-2">
                                                <h4 className="text-xs font-black uppercase tracking-widest text-slate-500">Infrastructure</h4>
                                                <div className="grid grid-cols-4 gap-2">
                                                    {colonyData.buildings.map((bid, i) => {
                                                        const b = Object.values(BUILDINGS).flat().find(x => x.id === bid);
                                                        if (!b) return null;
                                                        const Icon = b.Icon;
                                                        return (
                                                            <div key={i} className="aspect-square bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 border border-white/5" title={b.name}>
                                                                <Icon size={16}/>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>

                                            {/* Construction Panel */}
                                            <div className="space-y-2">
                                                <h4 className="text-xs font-black uppercase tracking-widest text-blue-500">Available Construction</h4>
                                                <div className="space-y-2 max-h-60 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-700">
                                                    {BUILDINGS.Infrastructure.filter(b => 
                                                        !colonyData.buildings.includes(b.id) && 
                                                        (!b.restrictions || b.restrictions.every(r => {
                                                            if (r === 'OnePerSystem') return !Object.values(colonies[selectedHex!]).some((c: ColonyDetails) => c.buildings.includes(b.id));
                                                            if (r === 'OceanicPlanet') return currentPlanet.type === 'Ocean World' || currentPlanet.type === 'Super M-Class';
                                                            if (r === 'GasGiant') return currentPlanet.type === 'Gas Giant' || currentPlanet.type === 'Super Saturn';
                                                            if (r === 'Nebula') return currentSystem.type === 'NEBULA';
                                                            if (r === 'Asteroids') return currentSystem.type === 'ASTEROID_FIELD';
                                                            if (r === 'Moons') return currentPlanet.moons > 0;
                                                            if (r === 'AsteroidBody') return currentPlanet.type === 'Asteroid';
                                                            return true;
                                                        })) &&
                                                        (!b.raceReq || b.raceReq === 0) &&
                                                        (!b.techReq || techLevels[b.techReq.category] >= b.techReq.level) &&
                                                        (!b.prerequisite || colonyData.buildings.includes(b.prerequisite))
                                                    ).map(b => (
                                                        <button 
                                                            key={b.id}
                                                            onClick={() => {
                                                                if (credits >= b.cost && (!b.resourceCost || Object.entries(b.resourceCost).every(([res, amt]) => inventory[res as ResourceType] >= amt!))) {
                                                                    setCredits(c => c - b.cost);
                                                                    if (b.resourceCost) {
                                                                        setInventory(prev => {
                                                                            const next = { ...prev };
                                                                            (Object.entries(b.resourceCost!) as [ResourceType, number][]).forEach(([res, amt]) => next[res] -= amt);
                                                                            return next;
                                                                        });
                                                                    }
                                                                    setColonies(prev => ({ ...prev, [selectedHex!]: { ...prev[selectedHex!], [selectedPlanetIdx]: { ...prev[selectedHex!]?.[selectedPlanetIdx], buildings: [...prev[selectedHex!]?.[selectedPlanetIdx].buildings, b.id] } } }));
                                                                    showToast(`${b.name} Constructed`);
                                                                } else {
                                                                    showToast("Insufficient Resources");
                                                                }
                                                            }}
                                                            className="w-full bg-slate-900 hover:bg-slate-800 p-3 rounded-xl border border-white/5 hover:border-blue-500/50 transition-all text-left group"
                                                        >
                                                            <div className="flex justify-between items-start mb-1">
                                                                <div className="flex items-center gap-2">
                                                                    <b.Icon size={14} className="text-slate-500 group-hover:text-blue-400 transition-colors" />
                                                                    <span className="font-bold text-xs group-hover:text-blue-400 transition-colors">{b.name}</span>
                                                                </div>
                                                                <span className="text-[10px] bg-black/40 px-1.5 py-0.5 rounded text-yellow-500">₵{b.cost}</span>
                                                            </div>
                                                            <div className="flex gap-2 text-[9px] text-slate-500 uppercase pl-6">
                                                                {b.popBonus && <span>Pop +{Math.round((b.popBonus || 0) * 100)}%</span>}
                                                                {b.credits && <span>Creds +{b.credits}</span>}
                                                                {b.rp && <span>RP +{b.rp}</span>}
                                                            </div>
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>

                                            {/* Shipyard Panel */}
                                            {hasShipyard && (
                                                <div className="space-y-2 pt-4 border-t border-white/10">
                                                    <h4 className="text-xs font-black uppercase tracking-widest text-purple-400 flex items-center gap-2"><Anchor size={12}/> Orbital Shipyard</h4>
                                                    <div className="grid grid-cols-2 gap-2">
                                                        {SHIP_CLASSES.map(cls => (
                                                            <button 
                                                                key={cls.id}
                                                                disabled={cls.techReq ? techLevels[cls.techReq.category] < cls.techReq.level : false}
                                                                onClick={() => handleBuildShip(cls.id)}
                                                                className={`p-2 rounded-lg border text-left text-[10px] transition-all ${cls.techReq && techLevels[cls.techReq.category] < cls.techReq.level ? 'opacity-50 border-white/5 bg-slate-900' : 'bg-slate-800 border-white/10 hover:border-purple-500 hover:bg-purple-900/20'}`}
                                                            >
                                                                <div className="font-bold text-white mb-1">{cls.name}</div>
                                                                <div className="text-slate-400">₵{cls.cost}</div>
                                                            </button>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                        </>
                                    )}
                                </div>
                            ) : (
                                /* No Colony */
                                <div className="p-6 bg-slate-900/30 rounded-xl border border-white/5 text-center space-y-4">
                                    <div className="text-slate-500 text-xs uppercase font-bold tracking-widest">Uninhabited World</div>
                                    {isPlayerFleet && selectedFleet?.ships.some(s => s.classId === 'colony_ship') && currentPlanet.habitable ? (
                                        <button 
                                            onClick={() => performColonize(selectedPlanetIdx)}
                                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase text-xs py-3 px-6 rounded-lg shadow-lg w-full flex items-center justify-center gap-2"
                                        >
                                            <Flag size={14}/> Establish Colony ({COLONY_COST}cr)
                                        </button>
                                    ) : (
                                        <div className="text-[10px] text-slate-600 italic">
                                            {currentPlanet.habitable ? "Requires Colony Ship in Orbit" : "Atmosphere Toxic - Cannot Colonize"}
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>
             ) : (
                <div className="text-slate-500 text-center mt-20 text-xs uppercase tracking-widest">No System Data</div>
             )}
          </div>
        )}

        {/* FLEET & COMBAT UI */}
        {selectedFleet && (
            <div className="absolute bottom-6 left-6 z-30 flex flex-col gap-2 animate-in slide-in-from-bottom duration-300">
                <div className="bg-black/90 backdrop-blur-md border border-white/10 rounded-xl p-4 w-80 shadow-2xl">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-1">Selected Fleet</div>
                            <div className="text-lg font-black text-white">{selectedFleet.id}</div>
                            <div className="text-xs text-blue-400">{selectedFleet.ships.length} Ships | {FORMATIONS[selectedFleet.formation].name}</div>
                        </div>
                        {isPlayerFleet && <div className="flex gap-2">
                             <button onClick={handleScrapFleet} className="p-2 bg-red-900/50 text-red-400 rounded hover:bg-red-800 transition-colors" title="Scrap Fleet"><Trash2 size={14}/></button>
                        </div>}
                    </div>
                    
                    <div className="space-y-2 max-h-40 overflow-y-auto mb-4 scrollbar-thin scrollbar-thumb-slate-700">
                        {selectedFleet.ships.map(ship => {
                            const cls = SHIP_CLASSES.find(c => c.id === ship.classId);
                            return (
                                <div key={ship.uuid} className="bg-slate-900/50 p-2 rounded flex justify-between items-center text-xs">
                                    <span className="font-bold text-slate-300">{cls?.name}</span>
                                    <div className="flex items-center gap-2">
                                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                            <div className="h-full bg-emerald-500" style={{ width: `${(ship.currentHull / (cls?.hull || 1)) * 100}%` }}></div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    {isPlayerFleet && (
                        <div className="grid grid-cols-2 gap-2">
                            {['outpost', 'starbase'].map(type => (
                                <button 
                                    key={type}
                                    disabled={!selectedFleet.ships.some(s => s.classId === 'const_ship')}
                                    onClick={() => performBuildStructure(type as 'outpost' | 'starbase')}
                                    className="p-2 bg-slate-800 hover:bg-blue-900/30 border border-white/5 rounded text-[10px] font-bold uppercase disabled:opacity-30"
                                >
                                    Build {type}
                                </button>
                            ))}
                            {/* Formation Selection */}
                            <div className="col-span-2 mt-2">
                                <div className="text-[9px] uppercase font-bold text-slate-500 mb-1">Formation Protocols</div>
                                <div className="flex gap-1">
                                    {(Object.values(FORMATIONS) as FormationStats[]).map(f => {
                                        const FIcon = f.icon;
                                        return (
                                            <button 
                                                key={f.id}
                                                onClick={() => changeFormation(selectedFleet.id, f.id)}
                                                className={`flex-1 p-2 rounded border transition-all flex justify-center ${selectedFleet.formation === f.id ? 'bg-blue-600 border-blue-400 text-white' : 'bg-slate-800 border-white/5 text-slate-500 hover:bg-slate-700'}`}
                                                title={f.desc}
                                            >
                                                <FIcon size={14}/>
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        )}
        
        {/* COMBAT OVERLAY */}
        {combatState && combatState.active && (
            <div className="absolute inset-0 bg-red-900/20 backdrop-blur-sm z-50 flex items-center justify-center">
                <div className="bg-black border border-red-500/50 w-[800px] h-[600px] rounded-2xl shadow-[0_0_50px_rgba(220,38,38,0.5)] flex flex-col overflow-hidden relative">
                    <div className="absolute top-0 inset-x-0 h-1 bg-red-500 animate-progress"></div>
                    <div className="p-6 bg-red-950/30 border-b border-red-500/20 flex justify-between items-center">
                        <div className="flex items-center gap-4 text-red-500">
                             <AlertTriangle size={32} className="animate-pulse"/>
                             <h2 className="text-3xl font-black uppercase tracking-tighter">Red Alert: Combat In Progress</h2>
                        </div>
                        <div className="text-right">
                             <div className="text-xs font-bold uppercase text-red-400 opacity-70">Sector {combatState.hexId}</div>
                             <div className="text-2xl font-bold tabular-nums text-white">Round {combatState.round}</div>
                        </div>
                    </div>
                    
                    <div className="flex-1 p-6 overflow-y-auto space-y-2 font-mono text-sm">
                        {combatState.logs.map((log, i) => (
                            <div key={i} className={`p-2 border-l-2 ${log.type === 'damage' ? 'border-orange-500 bg-orange-950/10 text-orange-200' : log.type === 'kill' ? 'border-red-600 bg-red-950/20 text-red-100 font-bold' : 'border-blue-500 bg-blue-950/10 text-blue-200'}`}>
                                <span className="opacity-50 mr-2">[{log.round}]</span> {log.message}
                            </div>
                        ))}
                    </div>

                    <div className="p-6 bg-slate-900 border-t border-white/10 flex justify-between gap-4">
                        <button onClick={resolveCombatRound} className="flex-1 bg-red-600 hover:bg-red-500 text-white font-black uppercase py-4 rounded-xl shadow-lg flex items-center justify-center gap-2 text-lg">
                            <Swords size={20}/> Engage Hostiles
                        </button>
                        <button onClick={handleRetreat} className="w-48 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold uppercase py-4 rounded-xl border border-white/10">
                            Retreat
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* MARKET MODAL */}
        {showMarket && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-20">
                <div className="bg-slate-900 w-full max-w-4xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-full">
                    <div className="p-6 border-b border-white/10 flex justify-between items-center">
                        <h2 className="text-2xl font-black uppercase tracking-tighter text-white flex items-center gap-3"><TrendingUp className="text-emerald-400"/> Galactic Commodity Exchange</h2>
                        <button onClick={() => setShowMarket(false)} className="p-2 hover:bg-white/10 rounded-full"><X/></button>
                    </div>
                    <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-8 overflow-y-auto">
                        {Object.keys(market).map(key => {
                            const res = key as ResourceType;
                            const item = market[res];
                            const config = RESOURCE_CONFIG[res];
                            const Icon = config.icon;
                            
                            return (
                                <div key={res} className="bg-slate-950 border border-white/5 rounded-xl p-6 relative overflow-hidden">
                                    <div className={`absolute top-0 right-0 p-2 ${item.trend === 'up' ? 'text-emerald-500' : item.trend === 'down' ? 'text-red-500' : 'text-slate-500'}`}>
                                        {item.trend === 'up' ? <TrendingUp size={20}/> : item.trend === 'down' ? <TrendingDown size={20}/> : <Minus size={20}/>}
                                    </div>
                                    
                                    <div className="flex items-center gap-4 mb-6">
                                        <div className={`p-4 rounded-full bg-slate-900 ${config.color}`}><Icon size={32}/></div>
                                        <div>
                                            <div className="text-xs font-bold uppercase text-slate-500">Commodity</div>
                                            <div className={`text-xl font-black uppercase ${config.color}`}>{config.name}</div>
                                        </div>
                                    </div>

                                    <div className="flex justify-between items-end mb-6">
                                        <div>
                                            <div className="text-xs text-slate-500 font-bold uppercase">Current Price</div>
                                            <div className="text-3xl font-mono text-white">₵{item.price.toFixed(2)}</div>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-xs text-slate-500 font-bold uppercase">In Stock</div>
                                            <div className="text-xl font-mono text-white">{Math.floor(inventory[res]).toLocaleString()}</div>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-3">
                                        <button onClick={() => tradeResource(res, 'buy', 100)} className="bg-emerald-900/30 hover:bg-emerald-900/50 text-emerald-400 border border-emerald-500/30 py-3 rounded-lg font-bold uppercase text-xs transition-colors">Buy 100</button>
                                        <button onClick={() => tradeResource(res, 'sell', 100)} className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-500/30 py-3 rounded-lg font-bold uppercase text-xs transition-colors">Sell 100</button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        )}
        
        {/* DIPLOMACY MODAL */}
        {showDiplomacy && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-12">
                <div className="bg-slate-900 w-full max-w-6xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col h-[80vh]">
                    <div className="p-6 border-b border-white/10 flex justify-between items-center">
                        <h2 className="text-2xl font-black uppercase tracking-tighter text-white flex items-center gap-3"><Globe className="text-blue-400"/> Diplomatic Channels</h2>
                        <button onClick={() => setShowDiplomacy(false)} className="p-2 hover:bg-white/10 rounded-full"><X/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {[...MAJOR_RACES.filter(r => r.id !== 0), ...MINOR_RACES].map(race => {
                            const rel = diplomacy[race.id] || { status: 'peace', opinion: 50 };
                            
                            return (
                                <div key={race.id} className={`bg-slate-950 border rounded-xl p-6 relative overflow-hidden transition-all ${rel.status === 'war' ? 'border-red-500/50 shadow-[0_0_20px_rgba(220,38,38,0.2)]' : rel.status === 'ally' ? 'border-blue-500/50 shadow-[0_0_20px_rgba(59,130,246,0.2)]' : 'border-white/5'}`}>
                                    <div className={`absolute top-0 inset-x-0 h-1 ${race.bgColor}`}></div>
                                    
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h3 className={`text-xl font-black uppercase ${race.color}`}>{race.name}</h3>
                                            <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">{race.homeworld} • {race.trait || (race.id === 6 ? 'Hive Mind' : 'Empire')}</div>
                                        </div>
                                        <div className={`px-2 py-1 rounded text-[10px] font-black uppercase ${rel.status === 'war' ? 'bg-red-900 text-red-200' : rel.status === 'ally' ? 'bg-blue-900 text-blue-200' : 'bg-slate-800 text-slate-400'}`}>
                                            {rel.status}
                                        </div>
                                    </div>

                                    <div className="mb-6 space-y-2">
                                        <div className="flex justify-between text-xs font-bold uppercase text-slate-500">
                                            <span>Relations</span>
                                            <span>{rel.opinion}/100</span>
                                        </div>
                                        <div className="h-1.5 bg-slate-900 rounded-full overflow-hidden">
                                            <div className={`h-full ${rel.opinion < 30 ? 'bg-red-500' : rel.opinion > 70 ? 'bg-emerald-500' : 'bg-yellow-500'}`} style={{ width: `${rel.opinion}%` }}></div>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-2">
                                        <button onClick={() => handleDiplomacyAction(race.id, 'gift')} className="bg-slate-900 hover:bg-slate-800 text-slate-300 py-2 rounded text-[10px] font-bold uppercase border border-white/5 flex items-center justify-center gap-2"><Gift size={12}/> Send Gift</button>
                                        <button onClick={() => handleDiplomacyAction(race.id, 'insult')} className="bg-slate-900 hover:bg-red-900/20 text-red-400 py-2 rounded text-[10px] font-bold uppercase border border-white/5 flex items-center justify-center gap-2"><MessageCircleX size={12}/> Insult</button>
                                        
                                        {rel.status !== 'war' && (
                                            <>
                                                <button onClick={() => handleDiplomacyAction(race.id, 'trade')} className="bg-slate-900 hover:bg-emerald-900/20 text-emerald-400 py-2 rounded text-[10px] font-bold uppercase border border-white/5 flex items-center justify-center gap-2"><Handshake size={12}/> Trade Route</button>
                                                <button onClick={() => handleDiplomacyAction(race.id, 'pact')} className="bg-slate-900 hover:bg-blue-900/20 text-blue-400 py-2 rounded text-[10px] font-bold uppercase border border-white/5 flex items-center justify-center gap-2"><FileSignature size={12}/> Non-Aggression</button>
                                                <button onClick={() => handleDiplomacyAction(race.id, 'ally')} className="col-span-2 bg-slate-900 hover:bg-purple-900/20 text-purple-400 py-2 rounded text-[10px] font-bold uppercase border border-white/5 flex items-center justify-center gap-2"><HeartHandshake size={12}/> Form Alliance</button>
                                            </>
                                        )}
                                        
                                        {rel.status === 'war' ? (
                                            <button onClick={() => handleDiplomacyAction(race.id, 'peace')} className="col-span-2 bg-emerald-900/30 hover:bg-emerald-800/50 text-emerald-200 py-2 rounded text-[10px] font-bold uppercase border border-emerald-500/30">Sue for Peace</button>
                                        ) : (
                                            <button onClick={() => handleDiplomacyAction(race.id, 'war')} className="col-span-2 bg-red-900/30 hover:bg-red-800/50 text-red-200 py-2 rounded text-[10px] font-bold uppercase border border-red-500/30">Declare War</button>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        )}

        {/* MINI MAP */}
        {showMinimap && (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-[280px] h-[160px] bg-black/80 border border-white/20 rounded-lg overflow-hidden shadow-2xl z-20 pointer-events-none">
                <div className="relative w-full h-full">
                    {/* Render simplified dots for stars */}
                    {Object.entries(galaxyData).map(([hex, sys]) => {
                         if (!exploredHexes.has(hex) && settings.fogOfWar) return null;
                         const [q, r] = hex.split(',').map(Number);
                         const x = HEX_SIZE * (Math.sqrt(3) * q + (Math.sqrt(3) / 2) * r) + DRAW_OFFSET_X;
                         const y = HEX_SIZE * (3 / 2 * r) + DRAW_OFFSET_Y;
                         const mx = minimapX(x);
                         const my = minimapY(y);
                         const owner = territories[hex] !== undefined ? [...MAJOR_RACES, ...MINOR_RACES].find(r => r.id === territories[hex]) : null;
                         
                         return (
                             <div key={hex} className="absolute w-1 h-1 rounded-full" style={{ left: mx, top: my, backgroundColor: getOwnerColor(owner) }} />
                         );
                    })}
                    {/* Viewport Rect */}
                    <div 
                        className="absolute border border-white/50"
                        style={{
                            left: minimapX(-camera.x + DRAW_OFFSET_X),
                            top: minimapY(-camera.y + DRAW_OFFSET_Y),
                            width: minimapX(window.innerWidth),
                            height: minimapY(window.innerHeight)
                        }}
                    />
                </div>
            </div>
        )}

      </div>
    </div>
  );
}
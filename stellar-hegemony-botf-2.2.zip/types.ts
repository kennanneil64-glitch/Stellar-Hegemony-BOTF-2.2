import { LucideIcon } from 'lucide-react';

export interface TechLevelsState {
  Biotech: number;
  Computers: number;
  Construction: number;
  Energy: number;
  Propulsion: number;
  Weapons: number;
}

export interface CameraState {
  x: number;
  y: number;
}

export interface Ship {
  uuid: string;
  classId: string;
  currentHull: number;
  ownerId: number;
}

export type FormationId = 'standard' | 'wedge' | 'wall' | 'skirmish' | 'echelon';

export interface Fleet {
  id: string;
  ownerId: number;
  hexId: string;
  ships: Ship[];
  hasMoved: boolean;
  formation: FormationId;
}

export interface ColonyDetails {
  buildings: string[];
  name: string;
  population: number;
  ownerId: number;
}

export interface ColonyMap {
  [hexId: string]: {
    [planetIndex: number]: ColonyDetails;
  };
}

export type ResourceType = 'alloys' | 'dilithium' | 'biomatter';

export interface MarketItem {
  price: number;
  trend: 'up' | 'down' | 'stable';
  volatility: number;
}

export type MarketState = Record<ResourceType, MarketItem>;
export type InventoryState = Record<ResourceType, number>;

export type WeatherType = 'NEBULA' | 'ION_STORM';

export interface WeatherPhenomenon {
  id: string;
  type: WeatherType;
  q: number; // Center Hex Q
  r: number; // Center Hex R
  radius: number; // Hex radius
  velocity: [number, number]; // [dQ, dR] per turn
  name: string;
}

export type RelationStatus = 'peace' | 'war' | 'ally' | 'trade' | 'pact' | 'hostile';

export interface DiplomaticRelation {
    status: RelationStatus;
    opinion: number; // 0-100
}

export type DiplomacyState = Record<number, DiplomaticRelation>; // Key is Race ID

export interface Structure {
    id: string;
    type: 'outpost' | 'starbase';
    ownerId: number;
    hexId: string;
}

export interface GameSettings {
    mapWidth: number;
    mapHeight: number;
    fogOfWar: boolean;
    difficulty: 'easy' | 'normal' | 'hard';
}

export interface SaveState {
  credits: number;
  researchPoints: number;
  turn: number;
  techLevels: TechLevelsState;
  colonies: ColonyMap;
  fleets: Fleet[];
  camera: CameraState;
  exploredHexes: string[];
  autoSaveFrequency: number;
  timestamp: string;
  inventory: InventoryState;
  market: MarketState;
  weather: WeatherPhenomenon[];
  diplomacy: DiplomacyState;
  structures: Structure[];
  settings: GameSettings; // New
}

// -----------------------------------

export interface TechLevel {
  icon: LucideIcon;
  color: string;
  levels: string[];
}

export type TechTree = Record<keyof TechLevelsState, TechLevel>;

export interface Race {
  id: number;
  name: string;
  homeworld: string;
  color: string;
  // Removed hardcoded 'hex', added relative position preference
  relX: number; // 0.0 to 1.0
  relY: number; // 0.0 to 1.0
  bgColor: string;
  borderColor: string;
  hexColor: string;
  isMinor?: boolean; // New
  trait?: string; // New
}

export interface PlanetType {
  type: string;
  color: string;
  shadow: string;
  desc: string;
  habitable: boolean;
  growthMod: number;
  miningBonus: ResourceType | null;
}

export type BuildingRestriction = 'OnePerSystem' | 'OceanicPlanet' | 'GasGiant' | 'Nebula' | 'Asteroids' | 'Moons' | 'AsteroidBody';

export interface Building {
  id: string;
  name: string;
  cost: number;
  resourceCost?: Partial<Record<ResourceType, number>>;
  Icon: LucideIcon;
  rp?: number;
  credits?: number;
  popBonus?: number;
  influenceBonus?: number;
  techReq?: TechRequirement;
  raceReq?: number;
  restrictions?: BuildingRestriction[]; // New
  prerequisite?: string; // New
}

export interface TechRequirement {
    category: keyof TechLevelsState;
    level: number;
}

export interface ShipClass {
  id: string;
  name: string;
  cost: number;
  resourceCost: Partial<Record<ResourceType, number>>;
  hull: number;
  shields: number;
  damage: number;
  accuracy: number;
  evasion: number;
  techReq: TechRequirement | null;
  abilities?: string[];
}

export interface FormationStats {
    id: FormationId;
    name: string;
    desc: string;
    icon: LucideIcon;
    modifiers: {
        damage: number;   
        accuracy: number;
        evasion: number;
        defense: number;  
    };
}

export interface PlanetData extends PlanetType {
    name: string;
    slots: number;
    moons: number;
    idx?: number;
}

export interface StarSystem {
  type: 'BLACK_HOLE' | 'BINARY' | 'PULSAR' | 'NEBULA' | 'ASTEROID_FIELD' | 'WORMHOLE' | 'ION_STORM' | 'HYPERGIANT' | 'NEUTRON_STAR' | 'WHITE_HOLE' | 'GRAVITON_ELLIPSE' | 'ROGUE_PLANET' | 'BADLANDS' | 'DARK_MATTER' | 'STAR' | 'OCEANIC' | 'VOLCANIC' | 'ANCIENT' | 'SHADOW';
  name: string;
  label: string;
  planets: PlanetData[];
  raceBg?: string;
  minorRaceId?: number; // New
}

export interface GalaxyDataMap {
  [hexId: string]: StarSystem;
}

export interface CombatLogEntry {
    round: number;
    message: string;
    type: 'damage' | 'kill' | 'info';
}

export interface CombatState {
    active: boolean;
    attackerId: string;
    defenderId: string;
    hexId: string;
    round: number;
    logs: CombatLogEntry[];
}

// File System Access API Types
export interface FileSystemHandle {
  kind: 'file' | 'directory';
  name: string;
}

export interface FileSystemFileHandle extends FileSystemHandle {
  kind: 'file';
  getFile(): Promise<File>;
  createWritable(): Promise<FileSystemWritableFileStream>;
}

export interface FileSystemWritableFileStream extends WritableStream {
  write(data: string | BufferSource | Blob): Promise<void>;
  seek(position: number): Promise<void>;
  truncate(size: number): Promise<void>;
}

declare global {
  interface Window {
    showSaveFilePicker(options?: any): Promise<FileSystemFileHandle>;
    showOpenFilePicker(options?: any): Promise<FileSystemFileHandle[]>;
  }
}